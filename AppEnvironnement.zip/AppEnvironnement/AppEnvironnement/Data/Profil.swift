//
//  Profil.swift
//  AppEnvironnement
//
//  Created by nicolas on 26/04/2021.
//

import Foundation
import SwiftUI

//Creation de la classe du profil utilisateur
class Profil : ObservableObject {
    // Identifiant du profil
    let id = UUID()
    let name: String   // Pseudo de l'utilisateur
    let password: String
    
    var fullName: String = ""
    var avatarURL : String  = ""// Possibelment une Image
    var mail : String? = ""
    // Generation des points et du score de l'utilisateur
    var rank : Ecorank = Ecorank.rank1

    let scoreMax = 2000



    //@Published var score = 0
    //@Published var ecoPoint : Int = 0
    
    @Published var score = 0 //Just for demo
    @Published var ecoPoint = 0 //Just for demo

    
    //Aspect social
    var amis: [UUID] = []

    
    // lien vers la liste des defis
    @Published var actionFinished = [FinishedAction]()
    @Published var challengeProposed = [ChallengeProposed]()
    @Published var productBuyed = [BuyedProduct]()

    init(name: String, password: String, fullName: String, avatarURL: String, mail: String) {
        self.name = name
        self.password = password
        self.fullName = fullName
        self.avatarURL = avatarURL
        self.mail = mail
    }
    
    func setRank(rank : Ecorank )  {
        switch score {
        case 0...100 :
            self.rank = Ecorank.rank1
        case 101...500 :
            self.rank = Ecorank.rank2
        case 501...1300 :
            self.rank = Ecorank.rank3
        default :
            self.rank = Ecorank.rank4
        }
    }
    
    //Fonction pour ajouter des points
    func addScore(point : Int) {
        self.score += point
        self.ecoPoint += point
    }
    func removeScore(point : Int){
        self.score -= point
        self.ecoPoint -= point
    }
    
    //Remboursement gift ?
    func addEcoPoint(point : Int) {
        self.ecoPoint += point
    }
    func removeEcoPoint(point : Int){
        self.ecoPoint -= point
    }
    
    
    func finishAction(actionId: UUID) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat
        let today = Date()
        self.actionFinished.append(FinishedAction(actionId: actionId, date: dateFormatter.string(from: today)))
        
        if dailyAction.contains(where: {$0.id == actionId}) {
            self.addScore(point: actionList.filter({$0.id == actionId})[0].score*multiplyNumber)
        }
        else {
            self.addScore(point: actionList.filter({$0.id == actionId})[0].score)
        }
    }
    
    func unfinishAction(actionId: UUID) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat
        let today = Date()
        
        self.actionFinished.removeAll {($0.actionId == actionId && $0.date == dateFormatter.string(from: today))}
        
        if dailyAction.contains(where: {$0.id == actionId}) {
            self.removeScore(point: actionList.filter({$0.id == actionId})[0].score*multiplyNumber)
        }
        else {
            self.removeScore(point: actionList.filter({$0.id == actionId})[0].score)
        }

    }
    
    func getFinishedAction() -> [UUID:Int] {
        let actionFinished = Dictionary(grouping: self.actionFinished, by: { $0.actionId })
        var actionFinishedOut: [UUID:Int] = [:]
        for action in actionFinished {
            actionFinishedOut[action.key] = action.value.count
        }
        
        return actionFinishedOut
        
        
    }
    
    func checkFinishedActionToday(actionId: UUID) -> Bool {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat
        let today = Date()
        
        if self.actionFinished.filter({$0.actionId == actionId && $0.date ==  dateFormatter.string(from: today)}).count != 0 {
            return true
        }
        else {
            return false
        }
        
    }


    func getPlacement() -> Int {
        let sortedProfileList = profilList.sorted(by: {$0.score > $1.score})
        return sortedProfileList.firstIndex(where: { (item) -> Bool in
                                        item.id == self.id }) ?? 0
    }

    func getChallengeInProgress() -> [ChallengeProposed] {
        let challenge = self.challengeProposed.filter({$0.receiverID == self.id && $0.dateStart != "" && $0.dateFinish == ""})
        return challenge
    }
    

    func getNumChallengeInProgress() -> Int {
        let challengeId = self.challengeProposed.filter({$0.receiverID == self.id && $0.dateStart != "" && $0.dateFinish == ""}).map{$0.challengeId}
        
        return challengeList.filter({challengeId.contains($0.id)}).count
    }
    
    func getChallengeFinished() -> [ChallengeProposed] {
        let challenge = self.challengeProposed.filter({$0.receiverID == self.id && $0.dateStart != "" && $0.dateFinish != ""})

        return challenge
    }
    
    func addChallenge(challenge: Challenge) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat
        let today = Date()
        self.challengeProposed.append(ChallengeProposed(proposerId: self.id, receiverID: self.id, challengeId: challenge.id, dateStart: dateFormatter.string(from: today), dateFinish: ""))
    }

    func removeChallenge(challenge: Challenge) {
        self.challengeProposed.removeAll {$0.challengeId == challenge.id}
    }
    
    func checkExistChallenge(challenge: Challenge) -> Bool {
        if self.challengeProposed.filter({$0.receiverID == self.id && $0.challengeId ==  challenge.id}).count != 0 {
            return true
        } else {
            return false
        }
    }
    
    func getNotExistChallenge() -> [Challenge] {
        var challengeOut: [Challenge] = []
        for challenge in challengeList {
            if self.challengeProposed.filter({($0.challengeId == challenge.id)}).count == 0 {
                challengeOut.append(challenge)
            }
        }
        return challengeOut
    }
    
    func validateChallenge(challenge: Challenge) {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = dateFormat
            let today = Date()
            var challengeProposedOut: [ChallengeProposed] = []
            
            for challengeProposed in self.challengeProposed {
                if challengeProposed.receiverID == self.id && challengeProposed.challengeId == challenge.id && challengeProposed.dateFinish == "" {
                    challengeProposedOut.append(ChallengeProposed(proposerId: challengeProposed.proposerId, receiverID: challengeProposed.receiverID, challengeId: challengeProposed.challengeId, dateStart: challengeProposed.dateStart, dateFinish: dateFormatter.string(from: today)))
                } else {
                    challengeProposedOut.append(ChallengeProposed(proposerId: challengeProposed.proposerId, receiverID: challengeProposed.receiverID, challengeId: challengeProposed.challengeId, dateStart: challengeProposed.dateStart, dateFinish: challengeProposed.dateFinish))
                }
            }
                
            self.challengeProposed = challengeProposedOut
            self.addScore(point: challenge.score)

        }
    
    
    func checkFinishedChallenge(challenge: Challenge) -> Bool {
        if self.challengeProposed.filter({$0.challengeId == challenge.id && $0.dateFinish != ""}).count != 0 {
            return true
        }
        else {
            return false
        }
        
    }
    
    func getDateFinishedChallenge(challenge: Challenge) -> Int {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat
        let today = Date()
        
        let dateStart = self.challengeProposed.filter({$0.challengeId == challenge.id && $0.dateFinish == ""})[0].dateStart
        let dateStartOut = dateFormatter.date(from: dateStart) ?? Date()

        
        let numberOfDaysPassed = Calendar.current.dateComponents([.day], from: dateStartOut, to: today).day!
        
        return challenge.durationByDay - numberOfDaysPassed
        
    }
    
    func getNumFriend() -> Int {
        return self.amis.count
    }

    
    func buyProduct(product: Produit) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat
        let today = Date()
        
        self.removeEcoPoint(point: product.prix)
        self.productBuyed.append(BuyedProduct(product: product, dateBuy: dateFormatter.string(from: today)))
    }
    
    func getEcoPoint() -> String {
        if self.ecoPoint >= 1000 {
            return "\(self.ecoPoint/1000)K"
        }
        else if self.ecoPoint >= 1000000{
            return "\(self.ecoPoint/1000000)M"
        }
        else if self.ecoPoint >= 1000000000{
            return "\(self.ecoPoint/1000000000)B"
        }
        else {
            return "\(self.ecoPoint)"
        }
    }
    
}

func displayDate(date: String) -> String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = dateFormat
    let dateOut = dateFormatter.date(from: date) ?? Date()
    dateFormatter.dateFormat = "d MMM y"
    
    return dateFormatter.string(from: dateOut)
}

func displayDateInterval(date: String, durationByDay: Int) -> String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = dateFormat
    var dateComponent = DateComponents()
     
    dateComponent.day = durationByDay
    
    let dateOut = Calendar.current.date(byAdding: dateComponent, to: dateFormatter.date(from: date) ?? Date()) ?? Date()
        
    dateFormatter.dateFormat = "d MMM y"
    
    return dateFormatter.string(from: dateOut)
}

