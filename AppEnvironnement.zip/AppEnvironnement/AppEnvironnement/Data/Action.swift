//
//  Action.swift
//  AppEnvironnement
//
//  Created by nicolas on 27/04/2021.
//

import Foundation
import SwiftUI


struct Action {
    let id = UUID()
    let name: String
    let score: Int
    
    var description = String()
}


let dateFormat = "yyyy-MM-dd"

struct FinishedAction {
    var actionId = UUID()
    var date = String()
    
    init(actionId: UUID, date: String) {
        self.actionId = actionId
        self.date = date
    }

}
