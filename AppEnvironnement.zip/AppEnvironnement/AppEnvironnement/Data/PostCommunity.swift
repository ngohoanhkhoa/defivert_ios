//
//  PostCommunity.swift
//  AppEnvironnement
//
//  Created by Mayte on 30/04/2021.
//

import Foundation


struct Post {
    let id = UUID()
    let date = Date()
    let imagePost : String
    var isLike: Bool
    
    let user : Profil
    
    let message: String
}


func formatDate(date: Date) -> String {
    let formatter4 = DateFormatter()
    formatter4.dateFormat = "d MMM y"
    return formatter4.string(from: date)
}


class PostDatabase: ObservableObject  {
    @Published var postList: [Post]
    
    init(postList: [Post]) {
        self.postList = postList
    }
}


