//
//  Database.swift
//  AppEnvironnement
//
//  Created by nicolas on 27/04/2021.
//

import Foundation
import SwiftUI
let leaf = Image(systemName: "leaf.fill")

var profilList = [
    Profil(name: "vanessajenkins", password: "boxcar", fullName: "Vanessa Jenkins", avatarURL: "vanessajenkins", mail: "vanessa.jenkins@example.com"),
    Profil(name: "lilliewebb", password: "millie", fullName: "Lillie Webb", avatarURL: "lilliewebb", mail: "lillie.webb@example.com"),
    Profil(name: "anitajackson", password: "houston1", fullName: "Anita Jackson", avatarURL: "anitajackson", mail: "anita.jackson@example.com"),
    Profil(name: "leoking", password: "windows", fullName: "Leo King", avatarURL: "leoking", mail: "leo.king@example.com"),
    Profil(name: "barrybyrd", password: "carpente", fullName: "Barry Byrd", avatarURL: "barrybyrd", mail: "barry.byrd@example.com")
]

var mainProfile = profilList[0]


var actionList = [
    Action(name: "Eteindre la lumière en sortant d'une pièce", score: 1, description:"Tu économises l'électricité" ),
    Action(name: "Faire pipi sous la douche", score: 2, description:"Tu économises une chasse d'eau (5-9L)" ),
    Action(name: "Trier ses déchets", score: 3, description: "Tu contribues au recyclage" ),
    Action(name: "Débrancher les appareils électriques après utilisation", score: 1, description: "Tu économises l'électricité" ),
    Action(name: "Boire l'eau du robinet", score: 1, description:"Tu économises de l'argent et du plastique" ),
    Action(name: "Faire sa lessive à basse température", score: 1, description: "Tu réduits ta facture d'électricité"),
    Action(name: "Se brosser les dents avec le robinet fermé", score: 2, description:"Tu économises l'eau" ),
    Action(name: "Utiliser un moteur de recherche écolo", score: 3, description: "Par exemple : Ecosia, Lilo" ),
    Action(name: "Prendre son propre sac de courses ", score: 2,description: "Tu réduis la consommation de plastique"),
    Action(name: "Apporter son propre mug au travail", score: 3, description: " Tu économises le plastique"),
    Action(name: "Prendre une douche plutôt qu'un bain", score: 2, description: " Tu économises l'eau ")
]

var dailyAction = actionList[0...4]




// Tous les challenges
var challengeList = [

    Challenge(name: "Un grand nettoyage au naturel", score: 200, durationByDay: 30, photoURL: "citron", description: "Combien as-tu de produits ménagers différents chez toi ? Regarde dans la cuisine, dans la salle de bain, le garage, la cave... Sais-tu ce que contiennent vraiment ses produits ? Il existe une alternative : fabriquer ses produits soi-même. Nous te proposons de te lancer dans la fabrication de tes propres produits ménagers", challengedujour: true ),
    Challenge(name: "Organiser une collecte de déchets", score: 400, durationByDay: 30, photoURL: "recyclage2", description: "Peut-être l'as-tu remarqué, mais lorsque tu te balades, certains endroits en ville ou en campagne sont jonchés de déchets. Quand tu vas pique-niquer dans un parc et que tu te retrouves face à plein de déchets... Beurk ! C'est plus enthousiasmant de réaliser un nettoyage à plusieurs. Tu peux donc prendre l'air, tout en étant utile pour la planète ! Prêt à te lancer ?", challengedujour: true),
    Challenge(name: "Organiser une Troc Party", score: 300, durationByDay: 30, photoURL: "TrocParty", description: "Dans une troc party, chacun propose de donner aux autres ses objets inutilisés. L'échange est gratuit. Chacun propose ses objets un à un. A la fin du troc, tu te seras débarassé d'objets qui ne te servaient plus, tout en faisant plaisir, et tu auras peut-être récupéré des trésors...", challengedujour: true),
    Challenge(name: "Désencombrer sa chambre", score: 200, durationByDay: 30, photoURL: "bedroom", description: "Ta chambre, c'est ton espace à toi. Parfois elle est bien rangée mais parfois, elle déborde. Tu as certainement des jeux, des livres, des vêtements qui ne sont plus adaptés à ton âge, ou des objets inutiles. Ce défi va t'aider à y voir plus clair, et à ne plus chercher des heures la moindre chaussette ! ", challengedujour: false),
    Challenge(name: "Acheter une gourde", score: 100, durationByDay: 30, photoURL: "gourde", description: "Une personne consomme 1,5 L/ jour, cela représente 540 bouteilles par an. Mais seulement 264 bouteilles seront réellement recyclées. Le reste sera soit brûlé, enfoui sous terre ou soit jeté dans la nature, les océans. Une solution pratique, économique, écologique et saine : la gourde. Achetez votre propre gourde ! Elle vous facilitera la vie, et vous ferez de sacrées économies ", challengedujour: false),
    Challenge(name: "Acheter un régulateur de débit d'eau", score: 100, durationByDay: 30, photoURL: "regulateur", description: "Un européen consomme en moyenne 150 L d'eau potable par jour ! Cela peut représenter une facture d'eau de quelques centaines d'euros mais comment réduire cette facture ? Les limiteurs de pression ou douchettes économiques. Ils ont pour fonction de diminuer la quantité d'eau consommée en gardant la même sensation de pression pour l'utilisateur", challengedujour: false)
   
]


var challengeProposedList = [
    ChallengeProposed(proposerId: profilList[0].id, receiverID: profilList[0].id, challengeId: challengeList[1].id, dateStart: "2021-04-12", dateFinish: "2021-04-25"),
    ChallengeProposed(proposerId: profilList[1].id, receiverID: profilList[0].id, challengeId: challengeList[2].id, dateStart: "2021-04-16", dateFinish: "2021-04-30"),
    
    ChallengeProposed(proposerId: profilList[0].id, receiverID: profilList[0].id, challengeId: challengeList[3].id, dateStart: "2021-05-01"),
    ChallengeProposed(proposerId: profilList[1].id, receiverID: profilList[0].id, challengeId: challengeList[4].id, dateStart: "2021-04-15"),
    
    ChallengeProposed(proposerId: profilList[1].id, receiverID: profilList[1].id, challengeId: challengeList[1].id, dateStart: "2021-04-15"),
    ChallengeProposed(proposerId: profilList[1].id, receiverID: profilList[1].id, challengeId: challengeList[2].id, dateStart: "2021-04-15"),
    ChallengeProposed(proposerId: profilList[1].id, receiverID: profilList[2].id, challengeId: challengeList[3].id, dateStart: "2021-04-15"),
    ChallengeProposed(proposerId: profilList[1].id, receiverID: profilList[2].id, challengeId: challengeList[4].id, dateStart: "2021-04-15"),
    ChallengeProposed(proposerId: profilList[1].id, receiverID: profilList[3].id, challengeId: challengeList[4].id, dateStart: "2021-04-15"),
    ChallengeProposed(proposerId: profilList[1].id, receiverID: profilList[3].id, challengeId: challengeList[0].id, dateStart: "2021-04-15"),
]

let challengeDatabase = ChallengeDatabase(challengeList: challengeProposedList)

//Butique
var restauration = [Produit(nom : "Bon pour un café !" , prix : 10 , image : "cafe",qte : 3,description : "A la découverte du CAFÉ SOLIDAIRE de DEUIL-LA-BARRE. Lieu de rencontre et de partage, à but non lucratif, géré par des bénévoles, proposant à des tarifs abordables de la nourriture et des boissons.Le café solidaire de Deuil-la-Barre est un espace d’accueil libre et gratuit, un lieu d’échange et de conversation.", durationByDay: 30),
                    
                    Produit(nom : "Panier de fruit " , prix : 200 , image : "panierFruit",qte : 3,description : "Venez apprecier un bon panier de fruit de saison offert en dessert par le restaurant EcoResto. Il s'agit d'un restaurant dont l'objectif n'est pas seulement de faire un bon chiffre d'affaires, mais aussi d'assumer la responsabilité de son impact social et environnemental. Pour ce faire, le restaurant applique des mesures permettant de réduire son empreinte carbone et de favoriser une consommation durable.Bonne dégustation !", durationByDay: 30),
                    
                    Produit(nom : "Bon pour un café !" , prix : 100 ,image : "cafe-solidaire",qte : 3,description : "Café citoyen. Ce lieu engagé, où se réunissent des associations, des collectifs, où se tiennent des conférences (parfois sérieuses…), n’aurait pas de sens s’il n’existait avant tout comme café, comme bar où se croisent par hasard (ou pas) des individus d’âge, d’origine, de milieux différents… mais qui ont tous en commun de participer, au moins le temps de leur passage au Café (ne serait-ce qu’en buvant un verre), à une démarche alternative au mode de production dominant.", durationByDay: 30)]


var atelierDIY = [Produit(nom : "DIY Bombe de bain" , prix : 600 ,image : "bombedebain",qte : 3, description : "L’idée de vous prélasser dans un bain relaxant, bienfaisant et multicolore vous séduit? Mieux, vous en rêvez?  Découvrez comment réaliser vos bombes de bain vous-même et multipliez les instants de bien-être grâce à cet atelier pétillant!", durationByDay: 10),
                  
                  Produit(nom : "BeeWrap DIY" , prix : 500 ,image : "DIYBeeWrap",qte : 3, description : "Confectionnez vos 2 bee wraps de dimensions 20x20 et 28x28 : choix des tissus, découpe...mise en pratique et utilisation, astuces. Ces emballages alimentaires réutilisables en cire d’abeille, remplacent avantageusement le film étirable et s’adaptent à vos contenants, sandwich… Idéal pour le goûter des enfants, et pour conserver des fruits coupés.", durationByDay: 30),
                  
                  Produit(nom : "Relooking de meuble" , prix : 1000 , image : "Atelier-relooking",qte : 3,description : "Vous avez envie de rajeunir un meuble vintage mais les techniques de peinture décorative vous semblent réservées aux experts ? Lasure, patine, cire, vernis, huile, pochoir… Ces techniques à la portée de tous permettent d’obtenir un résultat bluffant. Venez apprendre comment customiser un meuble en bois ! Notre animateur vous fait partager son expertise, pas à pas. Vous êtes totalement débutant en bricolage ? Ça tombe bien ! Nous sommes là pour vous aider à dire : C’EST MOI QUI L’AI FAIT !", durationByDay: 30),
                  
                  Produit(nom : "Atelier Couture" , prix : 1000 , image : "Atelier-couture",qte : 3,description : "Nous vous proposons un cours de couture ou un atelier DIY pour créer, réparer, transformer, embellir les vêtements et les objets textiles.", durationByDay: 30),
                  
                  Produit(nom : "Shampoing DIY" , prix : 800 ,image : "ShampoinDIY",qte : 3, description : "Le shampoing parfait qui ne rend pas les cheveux lourds, nourrit sans graisser et fait une chevelure digne de Raiponce, on en rêve, vous allez apprendre à le faire! En plus, la recette est personnalisée pour correspondre à votre type de cheveux et il dure des semaines et des semaines.", durationByDay: 30),
                  
                  Produit(nom : "Atelier Tawashi" , prix : 300 ,image : "Tawashi",qte : 3, description : "Apprenez à réaliser une éponge éternelle et écologique au cours de cet atelier. Originaire du Japon, le tawashi à une durée de vie très longue et est faite à partir de matériaux de récup’. Son plus : elle se lave en machine!", durationByDay: 30)]


var bonReduction = [Produit(nom : "-15%" , prix : 750 , image : "Ressourcerie",qte : 3,description : "Bienvenue a la Ressourcerie! La ressourcerie est un lieu où sont collectés tous les objets et matériaux dont leurs propriétaires n’ont plus besoin. Elle gère, sur un territoire donné, un centre de récupération, de valorisation, de revente et d’éducation à l’environnement. Son activité est inscrite dans le schéma de gestion des déchets du territoire.", durationByDay: 30),
                    
                    Produit(nom : "20% de reduction" , prix : 800 , image : "magasin-vrac",qte : 3,description : "Un magasin d'alimentation et de produits d'entretien vendu en vrac, sans emballage. Le client vient se servir aux distributeurs avec ses propres contenants choisissant ainsi la quantité qu'il désire. Le but du vrac c'est de diminuer vos déchets (fini les bacs de recyclage plastique qui débordent) !", durationByDay: 30),
                    
                    Produit(nom : "-20%" , prix : 600 ,image : "repair_cafe",qte : 3, description : "Le Repair Café est un lieu où l'on peut venir réparer ses objets. Des outils sont mis à disposition et des bricoleurs et réparateurs bénévoles accompagnent les participants à apprendre comment réparer leurs objets.", durationByDay: 30)]



var goodise = [Produit(nom : "Tote Bag" , prix : 800 , image : "tote-bag-biere",qte : 3,description : "Petite entreprise locale vous fait découvrir sa jolie collection de tote bag humoristique.", durationByDay: 30),
               
               Produit(nom : "Sac a vrac" , prix : 800 ,image : "sac-a-vrac",qte : 3,description : "La Petite Fabrique entreprise locale de reinsertion professionel, vous offre un ensemble de sac a vrac. Le sac à vrac représente la base du mode de vie zéro déchet. Très pratique pour les courses en vrac, ils ne pèse que quelques grammes. ... Le sac à vrac se décline en plusieurs tailles, du XS au XL, pour s'adapter à tous les aliments.", durationByDay: 30),
               
               Produit(nom : "Bee Wrap" , prix : 750 ,image : "beeWrap",qte : 3, description : "My little Bee vous offre un quite de Bee Wrap. Le Bee Wrap est un tissu recouvert de cire d'abeille. Pratique et écologique, il est une bonne alternative au film alimentaire.", durationByDay: 30),
               
               Produit(nom : "Echantillon" , prix : 500 , image : "cosmetique-naturel",qte : 3,description : "Petit echantillon de produits écologique d'une marque qui decide de n'integrer dans ses produits que des ingredients bio et naturel. Cela implique une restriction dans l'usage des éléments chimique nuisible pour la santé et l'environnement.", durationByDay: 30)]


//Community
var postList = [
    Post(imagePost: "vrac", isLike: false, user: profilList[4], message: "Aujourd'hui j'ai acheté mes fruits au marché local 🍊 #vrac #zeroWaste #defiVert"),
    Post(imagePost: "tri", isLike: false, user: profilList[2], message: "Je suis responsable et je pense à la planète, donc je trie mes poubelles #defiVert #triPoubelle"),
    Post(imagePost: "cosmetic", isLike: false, user: profilList[3], message: "Nouvelle recette de dentrifice maison 🥳 tellement facile #defiVert"),
    Post(imagePost: "ecolife", isLike: false, user: profilList[1], message: "J'ai fait la semaine dernière mes propes beeWrap, et maintenant mes restes dans mon frigo sont stylés, et en plus j'economise de l'argent, trop cool ! #defiVert"),
    Post(imagePost: "cafe", isLike: false, user: profilList[0], message: "Rien de mieux qu'un bon café dans une vraie tasse, car le goblet plastique change le goût et le plastique pollue la planète #defiVert"),
    Post(imagePost: "troc", isLike: false, user: profilList[1], message: "Je suis écolo #defiVert")
]


let postDatabase = PostDatabase(postList: postList)

// Khoa --------------
var oneChallengeForDay = challengeList[0]
let multiplyNumber = 2
// Khoa --------------

// Khoa --------------
var minutesMax = 0
let secondsMax = 30
// Khoa --------------
