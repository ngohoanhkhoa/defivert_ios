//
//  QuizData.swift
//  AppEnvironnement
//
//  Created by Margot on 03/05/2021.
//

import Foundation

import SwiftUI

struct QuestionQuiz: Identifiable , Hashable {
    let id = UUID()
    let question: String
    var score: Int
    var isVisible : Bool = true
    
    var reponses : [String]
    let bonneReponse : String
    let explicationReponse : String
   // var pictoPAO : Image?

}

var questionList = [
    QuestionQuiz(question: "Combien faut-il de litres d'eau pour fabriquer un jean?", score: 10,  reponses: ["100L", "1 000L", "5 000L", "10 000L"], bonneReponse: "10 000L", explicationReponse: "Il faut 10 000L d'eau pour fabfriquer un jean, ce qui est égal à 285 douche environ."),
    
    QuestionQuiz(question: "Entre 1960 et 2000, la production annuelle d'ordures ménagères de chaque français a...", score: 10, reponses: ["Doublé", "Triplé", "Diminué de moitié", "Est la même"], bonneReponse: "Doublé", explicationReponse: "Elle a doublé. Et c'est déjà beaucoup !!"),
    
    QuestionQuiz(question: "Les publicités déposées dans nos boîtes aux lettres, chaque année, représentent une forte quantité de papier. Quelle est cette quantité?", score: 10, reponses: ["22 kg", "33 kg", "40 kg", "47 kg"], bonneReponse: "40 kg", explicationReponse: "Chaque année, environ 18 milliards d'imprimés transitent dans nos boîtes aux lettres ce qui correspond en moyenne à 40 kg par foyer par an"),
   
    QuestionQuiz(question: "A quoi ressemble le pictogramme qui permet de connaître la période d'utilisation après ouverture (PAO) sur des emballages cosmétiques ?", score: 10, reponses: ["un tube de dentifrice ouvert", "un point d'interrogation", "un pot de crème ouvert", "un flacon ouvert"], bonneReponse: "un pot de crème ouvert", explicationReponse: "Ce pictogramme ressemble à un pot de crème ouvert"),
    
    QuestionQuiz(question: "Depuis quelques années le vélo en libre-service se développe énormément. Mais quelle ville est à l'origine de ce système?", score: 10, reponses: ["Lille", "Rennes", "Lyon", "Paris"], bonneReponse: "Lyon", explicationReponse: "C'est à Lyon que le Velo'v apparaît en 2005. Il ne faut pas oublier que La Rochelle fut la première à offrir des vélos dès 1974, les fameux vélos jaunes."),
                                                                                                              
    
]
