//
//  Produit.swift
//  AppEnvironnement
//
//  Created by nicolas on 27/04/2021.
//

import Foundation
import SwiftUI

struct Produit {
    // Identifiant du produit
    let  id = UUID()
    // nom du produit
    let nom : String
    // son prix
    let prix : Int
    // L'image du produit
    let image  : String
    // Potentiel quantite ,a voir si je le met sur la liste aussi ?
    var qte : Int
    
    let description : String
    
    let durationByDay: Int
    
}


struct BuyedProduct {
    let id = UUID()
    var product = Produit(nom: "", prix: 0, image: "", qte: 0, description: "", durationByDay: 0)
    var dateBuy = String()
    
    init(product: Produit, dateBuy: String) {
        self.product = product
        self.dateBuy = dateBuy
    }
}
