//
//  Ecorank.swift
//  AppEnvironnement
//
//  Created by nicolas on 27/04/2021.
//

import Foundation


enum Ecorank : String {
    case rank1 = "Eco novice"
    case rank2 = "Apprenti vert"
    case rank3 = "Gourou nettoyeur"
    case rank4 = "Super propre"
}
