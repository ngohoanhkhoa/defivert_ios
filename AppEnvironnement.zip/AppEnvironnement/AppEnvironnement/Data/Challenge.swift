
import Foundation

struct Challenge {
    
    
    let id = UUID()
    let name: String
    let score: Int

    let durationByDay: Int
    
    let photoURL: String
    let description: String
    let challengedujour: Bool
    

    func getNombreParticipant(challengeDatabaseObservedObject: ChallengeDatabase) -> Int {
        
        let participant = mainProfile.challengeProposed.filter({$0.challengeId == self.id}).map{ $0.receiverID }
        //let participant = challengeDatabaseObservedObject.challengeList.filter({$0.challengeId == self.id}).map{ $0.receiverID }
        
        let numUniqueParticipant = Array(Set(participant)).count
        
        return numUniqueParticipant
        
    }
    
}

struct ChallengeProposed {
    let id = UUID()
    let proposerId: UUID
    let receiverID: UUID
    let challengeId: UUID
    let dateStart: String
    var dateFinish = ""
    
}


class ChallengeDatabase: ObservableObject {
    @Published var challengeList: [ChallengeProposed]
    
    init(challengeList: [ChallengeProposed]) {
        self.challengeList = challengeList
    }
    
}
