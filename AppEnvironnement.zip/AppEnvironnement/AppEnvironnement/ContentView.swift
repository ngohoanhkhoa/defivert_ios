//
//  ContentView.swift
//  AppEnvironnement
//
//  Created by NGO HO Anh Khoa on 26/04/2021.
//

import SwiftUI

struct ContentView: View {
    @State private var selection = 0
    @ObservedObject var mainProfileObservedObject = mainProfile
    
    init() {
        //mainProfileObservedObject.challengeProposed = challengeProposedList
        
        mainProfileObservedObject.amis.append(profilList[1].id)
        mainProfileObservedObject.amis.append(profilList[2].id)
        
        
        mainProfileObservedObject.actionFinished.append(FinishedAction(actionId: actionList[0].id, date: "2021-04-01"))
        mainProfileObservedObject.actionFinished.append(FinishedAction(actionId: actionList[2].id, date: "2021-04-02"))
        mainProfileObservedObject.actionFinished.append(FinishedAction(actionId: actionList[3].id, date: "2021-04-03"))
        
        mainProfileObservedObject.score = 800
        mainProfileObservedObject.ecoPoint = mainProfileObservedObject.score
        
    }
    
    var body: some View {
        
        TabView(selection: $selection) {
            
            Accueil().tabItem {
                Image(systemName: (selection == 0  ? "house.fill" : "house"))
                Text("Accueil").foregroundColor(Color.red)
            }.tag(0)

            Defis().tabItem {
                Image(systemName: (selection == 1  ? "stopwatch.fill": "stopwatch"))
                Text("Défis")
            }.tag(1)
            
            Actions().tabItem {
                Image(systemName: (selection == 2  ? "hare.fill" : "hare"))
                Text("Actions")
            }.tag(2)
            
            Jeux().tabItem {
                Image(systemName: (selection == 3  ? "gamecontroller.fill" : "gamecontroller"))
                Text("Jeux")
            }.tag(3)
            
            Communaute().tabItem {
                Image(systemName: (selection == 4  ? "person.3.fill" : "person.3"))
                Text("Communauté")
            }.tag(4)
        }.accentColor(Color("vert1"))
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
