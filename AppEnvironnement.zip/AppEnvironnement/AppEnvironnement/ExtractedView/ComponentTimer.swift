import SwiftUI


struct QuizzTimer: View {
    
    @Binding var minutes: Int
    @Binding var seconds: Int
    
    let logoChrono : Image = Image(systemName: "timer")
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        VStack {
            Text("\(logoChrono) \(minutes):\(seconds)")
                .onReceive(timer) { _ in
                    if self.minutes > 0 {
                        if self.seconds == 0 {
                            self.seconds = 59
                            self.minutes = self.minutes - 1
                        } else {
                            self.seconds = self.seconds - 1
                        }
                        
                    } else if self.minutes == 0 {
                        if self.seconds != 0 {
                            self.seconds = self.seconds - 1
                        }
                        else {
                            self.minutes = 0
                            self.seconds = 0
                        }
                    }
                }
                .foregroundColor(Color("saumon")).font(Font.body.bold())
            
        }
    }
    
}
