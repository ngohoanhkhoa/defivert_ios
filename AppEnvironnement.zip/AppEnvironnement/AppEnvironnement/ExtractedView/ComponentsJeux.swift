//
//  ComponentsJeux.swift
//  AppEnvironnement
//
//  Created by Mayte on 28/04/2021.
//

import Foundation
import SwiftUI

// Bloc resultat de jeux
struct ResultatJeux : View {
    
    let titreResultat : String
    let pointGagne : String
    let explicationResultat : String
    
    var body: some View {
        ZStack{
            
            Color("bleu2")
            
            VStack{
                Spacer().frame(height: 30)
                
                Text(titreResultat)
                    .foregroundColor(Color("saumon")).bold()
                    .font(.system(size: 40))
                
                HStack{
                    Text(pointGagne).font(.system(size: 40))
                    Image(systemName: "leaf.fill").resizable().scaledToFit().frame(width: 50, height: 50)
                    
                    
                } .foregroundColor(Color("vert2"))
                
                Spacer().frame(height: 35)
                
                Text(explicationResultat).foregroundColor(Color("vert1")).font(Font.title3.bold()).bold().padding(30)
                
                Spacer()
                
                
                
                
            }.background(Color.white).cornerRadius(50).frame(width: 370, height: 450)
        }
        
        
    }
}


// Buton reponse jeux

struct BoutonJeux : View{
    let textReponse: String
    let couleurBouton : Color
    
    
    var body : some View {
        Text(textReponse)
            .foregroundColor(.white)
            .font(Font.title3.bold())
            .padding()
            .frame(width: 150, height: 150)
            .background(couleurBouton)
            .cornerRadius(40)
        
    }
}
// Buton Choix jeux

struct BoutonChoixJeux: View {
    let nomDuJeux: String
    let imagDuJeux: String
    let nombresDePoint: String
    let couleuDeFond: Color
    
    var body: some View {
        
        VStack {
            Image(systemName: imagDuJeux)
                .resizable()
                .scaledToFit()
                .frame(width: 40, height: 40)
                .foregroundColor(.white)
            Text(nomDuJeux)
                .font(Font.title.bold())
                .foregroundColor(.white)
            HStack {
                Text(nombresDePoint)
                    .foregroundColor(.white)
                Image(systemName: "leaf.fill")
                    .resizable()
                    .frame(width: 20, height: 20)
                    .foregroundColor(.white)
            }
        }.frame(width: 150, height: 150)
        .background(couleuDeFond)
        .cornerRadius(40)
        .padding()
        
        
    }
}

// Bloc quizz question
struct quizzQuestion: View {
    
    let logoQuestion : Image = Image(systemName: "leaf.fill")
    
    var numQuest : Int
    var question : String
    @Binding var minutes: Int
    @Binding var seconds: Int
    
    var body: some View {
        
        
        
        VStack{
            
            Text("\(numQuest) \(logoQuestion)").foregroundColor(Color("vert2")).padding(.top)
            
            
            Text(question).font(Font.title3.bold()).foregroundColor(Color("vert1")).padding()
            
            QuizzTimer(minutes: $minutes, seconds: $seconds)
                .padding(.bottom)
            
            
        }.background(Color.white)
        .cornerRadius(30)
        .padding()
        
        
        
        
    }
}
