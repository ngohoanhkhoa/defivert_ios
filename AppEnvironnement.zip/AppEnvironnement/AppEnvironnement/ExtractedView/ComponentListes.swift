//
//  ComponentListes.swift
//  AppEnvironnement
//
//  Created by Mayte on 29/04/2021.
//

import Foundation
import SwiftUI


// Khoa ---------
//Block pour la liste défis

struct ElementListeDefi: View {
    
    let nombrePoint: Int
    let nombreParticipant: Int
    let photoDefi: String
    let titreDefi: String
    let challengedujour: Bool
    
    let widthScreen: CGFloat
    var body: some View {
        HStack {
            Image(photoDefi)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: widthScreen * (1/3), height: 150, alignment: .center)
                .clipped()
            
            Spacer().frame(width: 0, height: 30)
            
            VStack(alignment: .leading){
                HStack{
                    Text(challengedujour ? "DÉFI DU JOUR" : "DÉFI MENSUEL")
                        .foregroundColor(Color(.white))
                        .frame(width: widthScreen * (3/6), alignment: .leading)
                    
                    Image(systemName: "chevron.right")
                        .font(.system(size:20)).accentColor(.white)
                        //.frame(width: widthScreen * (1/6) - 20, alignment: .trailing)
                    
                }.frame(width: widthScreen * (2/3) - 20, alignment: .leading)
                
                Spacer().frame(height:10)
                
                Text(titreDefi)
                    .bold()
                    .frame(height: 50, alignment: .leading)
                    .font(.system(size:20))
                    .foregroundColor(.white)
                
                
                Spacer().frame(height:10)
                
                HStack{
                    HStack{
                        Text("\(nombrePoint)")
                            .bold()
                        Image(systemName: "leaf")}
                        .foregroundColor(Color("vert2"))
                        .font(.system(size:15))
                    Spacer()
                    HStack{
                        Text("\(nombreParticipant) " + (nombreParticipant <= 1 ? "participant" : "participants") )
                        
                    }.foregroundColor(Color("vert3"))
                    .padding(.trailing, 10)
                    .font(.system(size:15))
                }
                
            }
            .frame(width: widthScreen * (2/3) - 30 , height: 150)
            .padding(.leading, 10)
            .background(Color(challengedujour ? "vert1" : "bleu1"))
            
        }.cornerRadius(30)
        .frame(height: 150)
        .padding(.horizontal, 10)
    }
    
}

//Block Liste Actions
struct ElementListeAction : View {
    let action: Action
    var actionDeJour: Bool = false //Pour les variante de actions de jour
    
    
    @ObservedObject var mainProfileObservedObject = mainProfile
    
    
    var body: some View {
        HStack{
            Button(action: {
                if mainProfileObservedObject.checkFinishedActionToday(actionId: action.id) {
                    mainProfileObservedObject.unfinishAction(actionId: action.id)
                }
                else {
                    mainProfileObservedObject.finishAction(actionId: action.id)
                }
            }, label: {
                Image(systemName: mainProfileObservedObject.checkFinishedActionToday(actionId: action.id) ? "checkmark.circle.fill" :  "circle" )
                    .resizable()
                    .scaledToFit()
                    .frame(width: 35, height: 25, alignment: .leading)
                    .foregroundColor(Color("vert1"))
            })
            VStack (alignment: .leading){
                
                
                Text(action.name)
                    .fontWeight(.medium)
                    .foregroundColor(Color("vert1"))
                Text(action.description).foregroundColor(.gray)
            }
            Spacer()
            HStack (alignment: .lastTextBaseline) {
                Text(actionDeJour ? "\(action.score*multiplyNumber)" : "\(action.score)").font(.title2).fontWeight(.medium).padding(-2.0)
                Image(systemName: "leaf.fill")
                    .resizable()
                    .padding(-3.0)
                    .scaledToFit()
                    .frame(width: 18, height: 18)
            } .foregroundColor(Color("vert2"))
            
        }.padding().background( actionDeJour ? Color("vert3"): Color.white)
    }
}
// Khoa ---------

// Element pour section de Profil
struct ElementSectionProfil: View {
    
    let picto : String
    let mainColor : Color
    let bkgColor : Color
    let titleSection : String
    
    var body: some View {
        HStack{
            Image(systemName: picto)
                .resizable()
                .scaledToFill()
                .padding(2)
                .frame(width: 30, height: 30)
                .padding(10)
                .background(mainColor)
                .cornerRadius(12)
                .foregroundColor(.white)
            
            Text(titleSection)
                .font(.title3).foregroundColor(Color("vert4"))
                .padding(.leading, 10)
            
            Spacer()
            
            
        } .padding(10).background(bkgColor)
    }}

