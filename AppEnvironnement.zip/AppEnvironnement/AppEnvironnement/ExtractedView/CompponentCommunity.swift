//
//  CompponentCommunity.swift
//  AppEnvironnement
//
//  Created by Mayte on 30/04/2021.
//

import Foundation
import SwiftUI


struct PostPhoto: View {

    let post : Post
    @State var likePhoto: Bool = false //post.isLike
    
    
    var body: some View {
        
        VStack {
            
            VStack(alignment: .leading) {
                HStack {
                    Image(post.user.avatarURL)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 30, height: 30, alignment: .leading)
                        .cornerRadius(25)
                    Text(post.user.fullName).font(.title2).bold().foregroundColor(Color("vert1"))
                    Text(post.user.rank.rawValue).font(.footnote).bold().foregroundColor(Color("vert2"))
                }
                Image(post.imagePost)
                    .resizable()
                    .scaledToFit()
                HStack {
                    Text(formatDate(date: post.date))
                        .font(.footnote).bold().foregroundColor(Color("vert1"))
                    Spacer()
                    Button(action: {
                        self.likePhoto.toggle()
                    }, label: {
                        Image(systemName: likePhoto ? "heart.fill" :  "heart" )
                            .resizable()
                            .scaledToFit()
                            .frame(width: 25, height: 25, alignment: .leading)
                            .padding()
                            .foregroundColor(likePhoto ? Color("vert2") :  .gray )
                    })
                }
                
                Text(post.message)
                
                
            }.padding()
        }
    }
}
