//
//  ComponentsProfil.swift
//  AppEnvironnement
//
//  Created by NGO HO Anh Khoa on 03/05/2021.
//

import Foundation
import SwiftUI


struct ActionDonneProfil : View {
    
    let actionName: String
    let descriptionAction : String
    let nombreDeFois : Int
    
    var body: some View {
        HStack{
            Image(systemName: "checkmark.circle.fill" )
                .resizable()
                .scaledToFit()
                .frame(width: 35, height: 25, alignment: .leading)
                .foregroundColor(Color("saumon2"))
            
            VStack (alignment: .leading){
                
                Text(actionName)
                    .fontWeight(.medium)
                    .foregroundColor(Color("saumon"))
                Text(descriptionAction).foregroundColor(.gray)
            }
            Spacer()
            Text("x \(nombreDeFois)").font(.title2)
                .fontWeight(.medium).padding(-2.0)
                .foregroundColor(Color("saumon"))
                .padding(.trailing, 20)
        } .padding()
    }
}

struct DefisDonneProfil : View {
    
    @ObservedObject var challengeDatabaseObservedObject = challengeDatabase
    
    let challengeId: UUID
    let challengeFinishDate : String
    let proposedByFriend: UUID?
    
    var body: some View {
        HStack{
            VStack (alignment: .leading, spacing:5){
                
                HStack{
                    Image(systemName: "checkmark.circle.fill" )
                        .resizable()
                        .scaledToFit()
                        .frame(width: 35, height: 25, alignment: .leading)
                        .foregroundColor(Color("vert2"))
                    VStack(alignment: .leading) {
                        Text("\(challengeList.filter{$0.id == challengeId}[0].name)")
                            .fontWeight(.medium)
                            .foregroundColor(Color("vert1"))
                        Text("\(proposedByFriend != nil ? "proposé par \(profilList.filter{$0.id == proposedByFriend}[0].fullName)" : "")")
                            .fontWeight(.light)
                            .foregroundColor(.gray)
                    }
                    Spacer()
                }
                HStack {
                    Text(displayDate(date: challengeFinishDate))
                        .font(.footnote).bold().foregroundColor(Color("vert2")).padding(.leading, 5)
                    Spacer()
                    Text("\(challengeList.filter{$0.id == challengeId}[0].getNombreParticipant(challengeDatabaseObservedObject: challengeDatabaseObservedObject)) participants ").font(.footnote).foregroundColor(.gray).padding(.trailing, 5)
                }
                
            }
        }.padding()
        
    }
}

struct AmisProfil : View {
    
    let userProfil: Profil
    
    var body: some View {
        HStack{
            Image(userProfil.avatarURL)
                .resizable()
                .scaledToFit()
                .frame(width: 50, height: 50, alignment: .leading)
                .cornerRadius(25)
           
            VStack (alignment: .leading){
                Text(userProfil.fullName)
                    .fontWeight(.medium)
                    .foregroundColor(Color("vert1"))
                    .font(.title3)
                Text("@\(userProfil.name)").foregroundColor(.gray)
            }
            Spacer()
        }.padding(10).background(Color.white)
            
    }
}

//planet
struct PlanetJauge: View {
    
    var porcentage: CGFloat = 0
    init (scoreUser : Int, scoreMax : Int) {
         porcentage = CGFloat(scoreUser)*80/CGFloat(scoreMax)}
    var body: some View {
        ZStack (alignment: .bottom){
            
            
            Image("terre")
                .resizable()
                .scaledToFill()
                .frame(width: 80, height: 80, alignment: .center)
                .foregroundColor(Color("gris"))
            
            Image("terre")
                .resizable()
                .aspectRatio(contentMode: .fill)//.scaledToFill()
                .frame(width: 80, height: porcentage, alignment: .bottom)
                .foregroundColor(Color("vert2"))
                .clipShape(Rectangle())
            
        }
    }
}


// Block pour montrer les cadeaux
struct TicketBoutique : View {
   
    let produit: Produit
    let dateBuy : String
    
    var body : some View {
        VStack{
     
            HStack{
                Image(produit.image)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 100, height: 100)
                    .clipped()
                
       
                VStack(alignment: .leading) {

                    Text(produit.nom)
                        .font(.system(size:20))
                    Spacer()
                    Text("Date d'achat: \(displayDate(date: dateBuy)) ").font(.system(size:11))
                    Text("Date de validité: \(displayDateInterval(date: dateBuy, durationByDay: produit.durationByDay)) ").font(.system(size:11)).bold()
                   Spacer().frame(height:8)
                    HStack{
                    Text("\(produit.prix)")
                        .bold()
                    Image(systemName: "leaf.fill")
               
                    }.foregroundColor(Color("vert2")).font(.system(size:20))
                    
                }
                Image(systemName: "qrcode").font(.system(size:90))
            }
            
        }.padding().border(Color("vert2"), width: 2)
    }
  
}
