//
//  ComponentsClassement.swift
//  AppEnvironnement
//
//  Created by Mayte on 29/04/2021.
//

import Foundation
import SwiftUI


// Block Classement
struct ClassementButton: View {
    let placement: Int
    let avatar: String
    
    var colorRanking = Color("gold")
    
    init(placement: Int, avatar: String) {
        
        self.placement = placement + 1
        self.avatar = avatar
        
        switch placement {
        case 0:
            self.colorRanking = Color("gold")
        case 1:
            self.colorRanking = Color("silver")
        case 2:
            self.colorRanking = Color("bronze")
        default:
            self.colorRanking = Color("vert1")
        }
    }

    var body: some View {
            HStack{
                Spacer()
                ZStack{
                    Image(avatar)
                     .resizable()
                     .scaledToFill()
                     .frame(width: 100, height: 100)
                     .cornerRadius(60)
                    
                    Circle().frame(width: 30, height: 30).foregroundColor(Color("bleu1"))
                        .offset(x: 30, y: 30)
                    Text("\(placement)").bold().foregroundColor(.white).offset(x: 30, y: 30)
                    
                }.padding()
                Spacer()
                VStack{
                    Image (systemName: "crown.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 35, height: 35)
                        .foregroundColor(colorRanking)
                    
                    Text("Félicitations").foregroundColor(.white).bold()//.font(.system(size: 25))
                    
                    Text("Aujourd'hui, vous êtes en").foregroundColor(.white).frame(width: 100, height: 50)
                    
                    Text(placement == 1 ? "1er place": "\(placement)ème place").foregroundColor(Color("vert1")).bold()
                }.padding()
                Spacer()
            }
            .frame(height:170)
            .background(Color("vert2"))
            .cornerRadius(20).padding()
    }
}
 

// Element Liste Ranking
struct ElementListeRanking : View {
    
    let userProfil: Profil
    let positionRanking: Int
    
    //Pour diferencier l'user du reste
    let isUser: Bool
    
    var colorRanking = Color("gold")
    
    init(userProfil: Profil, positionRanking: Int, isUser: Bool) {
        
        self.userProfil = userProfil
        self.positionRanking = positionRanking
        self.isUser = isUser
        
        switch positionRanking {
        case 0:
            self.colorRanking = Color("gold")
        case 1:
            self.colorRanking = Color("silver")
        case 2:
            self.colorRanking = Color("bronze")
        default:
            self.colorRanking = isUser ? Color("vert3"): Color.white
        }
    }
    
    var body: some View {
        HStack{
            Text("\(positionRanking+1)").font(.title2).fontWeight(.medium).frame(width:50).foregroundColor(Color("vert2"))
            
            Image(userProfil.avatarURL)
                .resizable()
                .scaledToFit()
                .frame(width: 50, height: 50, alignment: .leading)
                .cornerRadius(25)
           
            VStack (alignment: .leading){
                Text(userProfil.fullName)
                    .fontWeight(.medium)
                    .foregroundColor(Color("vert1"))
                    .font(.title3)
                Text("@\(userProfil.name)").foregroundColor(.gray)
            }
            Spacer()
            Image(systemName: "crown.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 25, height: 25)
                .foregroundColor(colorRanking)
                .padding(10)
        }.padding(10).background(isUser ? Color("vert3"): Color.white)
            
    }
}
