//
//  ListeAction.swift
//  AppEnvironnement
//
//  Created by Mayte on 28/04/2021.
//

import SwiftUI

struct ListeAction: View {
    
 
    
    var body: some View {
        ZStack {
            Color("bleu2")
            
            VStack {
                
                VStack(alignment: .leading) {
                    HStack {
                        Image("person1")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 30, height: 30, alignment: .leading)
                            .cornerRadius(25)
                        Text("Tom tom |").font(.title2).bold().foregroundColor(Color("vert1"))
                        Text("Tom tom").font(.footnote).bold().foregroundColor(Color("vert2"))
                    }
                    Image("person1")
                        .resizable()
                        .scaledToFit()
                    Text("2 Mai 2020")
                        .font(.footnote).bold().foregroundColor(Color("vert1"))
                    
                    Text("2 Mai 2020")
                        
                    
                }.padding()
                
                
                
                // example de elements pour liste
                
                ElementListeAction(actionName: "Étaint la lumiere en sortant", descriptionAction: "Economiser l'electricité", nombrePointAction: "3", actionDone: true, actionDeJour: true)
             
                ElementListeAction(actionName: "Pipi sur la douche", descriptionAction: "Economiser l'electricité", nombrePointAction: "3", actionDone: false, actionDeJour: false)
                ElementListeAction(actionName: "Pipi sur la douche", descriptionAction: "Economiser l'eau", nombrePointAction: "2", actionDone: true, actionDeJour: true)
                
            }
        }
        
    }
}






struct ListeAction_Previews: PreviewProvider {
    static var previews: some View {
        ListeAction()
    }
}
