//
//  ComponentShoping.swift
//  AppEnvironnement
//
//  Created by Mayte on 29/04/2021.
//

import Foundation
import SwiftUI

// New Mayte

struct ListeHorizontale : View {
    var produits : [Produit]
    
    var body : some View {
        ScrollView (.horizontal) {
            HStack{
                ForEach(produits, id: \.id){ produit in
                    NavigationLink(
                        destination: DetailProduit(leProduit :produit).navigationBarHidden(true),
                        label: {
                            ProduitBoutique(image: produit.image , label:produit.nom, prix: produit.prix
                            ).padding(.trailing, 5)
                            .padding(.vertical)
                        })
                }
            }.padding()
        }
    }
    
}


struct ProduitBoutique : View{
    let image : String
    let label : String
    var prix : Int
    var leaf = Image(systemName: "leaf.fill").resizable()
    var body : some View {
        VStack{
            Image(image)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 180, height : 120, alignment: .center)
                .clipShape(Rectangle())
            Text(label)
                .fontWeight(.medium)
                .foregroundColor(Color("vert1"))
                .multilineTextAlignment(.center)
                .frame(width: 150, height : 50)
            Text("\(prix) \(leaf)").bold()
                .foregroundColor(Color("vert2"))
                .padding(.bottom, 10)
        }.background(Color("vert3")).cornerRadius(12)
        .frame(width: 180, height : 150)
    }
}

// New Mayte
