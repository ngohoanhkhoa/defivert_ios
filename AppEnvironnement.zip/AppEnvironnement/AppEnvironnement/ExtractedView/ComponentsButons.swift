//
//  ComponentsButons.swift
//  AppEnvironnement
//
//  Created by Mayte on 29/04/2021.
//

import Foundation
import SwiftUI

// Khoa -------
// Button rond challenge
struct ChallengeButton: View {
    @Binding var buttonIcon: String
    let challengedujour: Bool
    var body: some View {
        ZStack{
            Circle()
                .fill(Color(challengedujour ? "vert1" : "bleu1"))
                .frame(width:70, height: 70)
            
            Image(systemName: buttonIcon)
                .resizable()
                .frame(width: 50, height: 50)
                .background(Color( "vert2"))
                .cornerRadius(30)
                .foregroundColor(Color("bleu1"))
        }
    }
}
// Khoa -------

// Buton appareil photo
struct AppareilButton: View {
    
    var body: some View {
        
            
            ZStack{
                
                Circle()
                    .fill(Color("vert2"))
                    .frame(width:70, height: 70)
           
                Image(systemName: "camera.circle")
                    .resizable()
                    .frame(width: 60, height: 60)
                    .background(Color("vert1"))
                    .cornerRadius(30)
                    .foregroundColor(Color("vert2"))
                
            }
        
    }
}



// Buton Check
struct CheckButton: View {
    
    var body: some View {
        
        Button(action: {
            
        }, label: {
            
            ZStack{
                Circle()
                    .fill(Color("vert1"))
                    .frame(width:70, height: 70)
                Image(systemName: "checkmark.circle")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .background(Color("vert2"))
                    .cornerRadius(30)
                    .foregroundColor(Color("vert1"))
                
            }
            
        })
        
    }
}

// Khoa -------
struct BoutonValiderChallenge: View {
    @ObservedObject var mainProfileObservedObject = mainProfile
    let challenge: Challenge
    @Binding var buttonIcon: String
    @Binding var disableIcon: Bool
    var body: some View {
        Button(action: {
            mainProfileObservedObject.validateChallenge(challenge: challenge)
            buttonIcon = "checkmark.circle"
            disableIcon = true
        }, label: {
            Text("Valider mon défi").bold()
                .font(Font.title3)
                .padding(20)
                .foregroundColor(.white)
                .background(Color("vert2"))
                .cornerRadius(30)
        })
        .opacity(mainProfileObservedObject.checkFinishedChallenge(challenge: challenge) ? 0 : 1)
        .disabled(mainProfileObservedObject.checkFinishedChallenge(challenge: challenge))
    }
}
// Khoa -------

// Button valider simple

struct BoutonValider: View {
    let textBouton: String
    
    var body: some View {
        Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
            Text(textBouton).bold()
                .font(Font.title3)
                .padding(20)
                .foregroundColor(.white)
                // .frame(width: 300, height: 60)
                .background(Color("vert2"))
                .cornerRadius(30)
        })
    }
}


struct IconeNavigation : View  {
    
    let picto : String
    
    var body: some View{
        
        Image(systemName: picto)
            .resizable()
            .scaledToFill()
            .frame(width: 30, height: 30)
            .foregroundColor(.gray)
    }
}

struct BoutonValiderBoutique: View {
    let textBouton: String
    let action : () -> Void
    var body: some View {
        
        Button(action: action , label: {
            Text(textBouton).bold()
                .font(Font.title3)
                .frame(width: UIScreen.main.bounds.width*0.90)
                .padding(10)
                .foregroundColor(.white)
                .background(Color("vert2"))
                .cornerRadius(30)
            
        })
    }
}
