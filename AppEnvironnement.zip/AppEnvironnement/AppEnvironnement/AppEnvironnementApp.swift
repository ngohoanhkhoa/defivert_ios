//
//  AppEnvironnementApp.swift
//  AppEnvironnement
//
//  Created by Mayte on 26/04/2021.
//

import SwiftUI

@main
struct AppEnvironnementApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
