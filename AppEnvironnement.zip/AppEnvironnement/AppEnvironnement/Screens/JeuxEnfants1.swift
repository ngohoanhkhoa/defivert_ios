//
//  JeuxEnfants1.swift
//  AppEnvironnement
//
//  Created by Margot on 30/04/2021.
//

import SwiftUI

struct JeuxEnfants1: View {
    //let reponse: Response
    let reponseStatut: Bool
    let explicationReponse: String
    var isPresented = false
    @Binding var numQuestion : Int
    @Binding var isOver : Bool
    @Binding var hideHimself : Bool
    
    //Khoa----
    @Binding var minutes: Int
    @Binding var seconds: Int
    //Khoa----
    
    func nextPage() {
        
    }
    var body: some View {
            
            ZStack{
                
                Color("bleu2").ignoresSafeArea()
                
                VStack{
                   // Text(String(reponseStatut))
                    
                    //Spacer()
                    Text("Question \(numQuestion+1)/5")
                        .font(Font.title.bold())
                        .foregroundColor(Color("vert1")).padding(.top)
                    
                   // Spacer().frame(height: 30)
                    
                    ResultatJeux(titreResultat: reponseStatut == true ? "Bravo ! 🎉": "Oups ! 😢", pointGagne: reponseStatut == true ? "+ 10": "0", explicationResultat: explicationReponse)
                    
                    //Spacer().frame(height: 30)
                    
                    BoutonValider2( action :{
                        if numQuestion < questionList.count-1 {
                        numQuestion+=1
                        hideHimself = false
                            minutes = minutesMax
                            seconds = secondsMax
                        }
                        else{
                          isOver = true
                        hideHimself = false
                            
                            minutes = minutesMax
                            seconds = secondsMax
                            
                        }
                        
                    },textBouton: "Question suivante")
                    
                    Spacer()
                    
                }
                    
            }
            
        
        }
}

