//
//  Defis.swift
//  AppEnvironnement
//
//  Created by NGO HO Anh Khoa on 28/04/2021.
//

import SwiftUI

struct Defis: View {
    @ObservedObject var mainProfileObservedObject = mainProfile
    @ObservedObject var challengeDatabaseObservedObject = challengeDatabase
    
    var body: some View {
        NavigationView {
            GeometryReader {reader in
                VStack{
                    HStack {
                        Text("Défis").bold()
                            .foregroundColor(Color("vert2")).font(.title2)
                        
                        Spacer()
                        HStack {
                            Text("Solde :").foregroundColor(.gray).font(.system(size: 15))
                            Text(mainProfileObservedObject.getEcoPoint()).font(.system(size: 15)).fontWeight(.medium)
                            Image(systemName: "leaf.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 15, height: 15)
                        }.foregroundColor(Color("vert2"))
                        
                    }.frame(height: 30).padding(10)
                    
                    ScrollView {
                        
                        VStack(alignment:.leading, spacing: 15 ) {
                            
                            Text(mainProfileObservedObject.getChallengeInProgress().isEmpty ? "Il n'y a plus de défis en cours" : "En cours")
                                .font(.headline).foregroundColor(.gray)
                                .padding(.leading, 10).padding(.vertical, 10)
                                .textCase(.uppercase)
                            
                            ForEach(mainProfileObservedObject.getChallengeInProgress(), id: \.id) {challenge in
                                NavigationLink(
                                    destination: Defienfant(challenge: challengeList.filter{$0.id == challenge.challengeId}[0]),
                                    label: {
                                        ElementListeDefi(nombrePoint: challengeList.filter{$0.id == challenge.challengeId}[0].score,
                                                         nombreParticipant: challengeList.filter{$0.id == challenge.challengeId}[0].getNombreParticipant(challengeDatabaseObservedObject: challengeDatabaseObservedObject),
                                                         photoDefi: challengeList.filter{$0.id == challenge.challengeId}[0].photoURL,
                                                         titreDefi: challengeList.filter{$0.id == challenge.challengeId}[0].name,
                                                         challengedujour: challengeList.filter{$0.id == challenge.challengeId}[0].challengedujour,
                                                         widthScreen: reader.size.width)
                                    })
                            }
                            
                            
                            Text(mainProfileObservedObject.getNotExistChallenge().isEmpty ? "Il n'y a plus de nouveaux défis" : "Nouveaux défis")
                                .font(.headline).foregroundColor(.gray)
                                .padding(.leading, 10).padding(.vertical, 10)
                                .textCase(.uppercase)
                            
                            
                            ForEach(mainProfileObservedObject.getNotExistChallenge(), id:\.id) { challenge in
                                NavigationLink(
                                    destination: Defienfant(challenge: challenge),
                                    label: {
                                        ElementListeDefi(nombrePoint: challenge.score,
                                                         nombreParticipant: challenge.getNombreParticipant(challengeDatabaseObservedObject: challengeDatabaseObservedObject),
                                                         photoDefi: challenge.photoURL,
                                                         titreDefi: challenge.name,
                                                         challengedujour: challenge.challengedujour,
                                                         widthScreen: reader.size.width)
                                    })
                                
                            }

                        }
                    }

                    .navigationBarHidden(true).navigationBarTitleDisplayMode(.inline)
                    
                }
            }
        }
    }
}

struct Defis_Previews: PreviewProvider {
    static var previews: some View {
        Defis()
    }
}
