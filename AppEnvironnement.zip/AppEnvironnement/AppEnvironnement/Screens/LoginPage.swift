//
//  LoginPage.swift
//  AppEnvironnement
//
//  Created by nicolas on 30/04/2021.
//
import SwiftUI

struct LoginPage: View {
    @Binding var isLogged : Bool
    @State var identifiant : String = ""
    @State var password : String = ""
    var body: some View {
        VStack {
            Spacer()
            Image("DefiVert")
            Spacer()
            TextField("Truc", text: $identifiant)
                .padding(5)
                .background(Color("vert2"))
                .padding(.bottom,20)
                .cornerRadius(5.0)
            
            SecureField("Password", text : $password)
                .padding(5)
                .background(Color("vert2"))
                .padding(.bottom,20)
                .cornerRadius(5.0)
            
            BoutonValider2(action : {
               isLogged = auth(/*id : identifiant , mdp : password*/)
            }, textBouton:"Login")
            BoutonValider2(action : {
               isLogged = auth(/*id : identifiant , mdp : password*/)
            }, textBouton:"Je n'ai pas de compte")
            Spacer()
        }
    }
}

func auth(/*id : String , mdp : String */) -> Bool{
   // var loginCheck : Profil
  /*  for profil in profilList{
        if profil.mail == id {
            loginCheck = profil
            if loginCheck.password == mdp {
                print("loggin succeed")
                
                return true
            }
            else{
                print("profil suivant")
            }
        }
        
    }*/
   print("le compte n'existe pas ")
    return true
}
/*
struct LoginPage_Previews: PreviewProvider {
    @State var isLogged = false
    static var previews: some View {
        LoginPage()
    }
}
*/

struct BoutonValider2: View {
    let action : () -> Void
    let textBouton: String
    var body: some View {
        
        Button(action:
                action,
               label: {
                Text(textBouton)
                    .font(Font.title3)
                    .bold()
                    .foregroundColor(.white)
                    .frame(width : UIScreen.main.bounds.width*0.75 )
                    .padding()
                    .background(Color("vert2"))
                    .cornerRadius(30)
                
               })
    }
}
