//
//  Actions.swift
//  AppEnvironnement
//
//  Created by NGO HO Anh Khoa on 28/04/2021.
//

import SwiftUI

struct Actions: View {
    
    @ObservedObject var mainProfileObservedObject = mainProfile
    
    var body: some View {
        NavigationView {
            
            VStack {
                HStack {
                    Text("Actions").bold()
                        .foregroundColor(Color("vert2")).font(.title2)
                    Spacer()
                    HStack {
                        Text("Solde :").foregroundColor(.gray).font(.system(size: 15))
                        Text(mainProfileObservedObject.getEcoPoint()).font(.system(size: 15)).fontWeight(.medium)
                        Image(systemName: "leaf.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 15, height: 15)
                    }.foregroundColor(Color("vert2"))
                    
                }.frame(height: 30).padding(10)
                
                ScrollView {
                    
                    VStack(alignment: .leading, spacing:1){
                        Text("Actions du jour")
                            .font(.headline).foregroundColor(.gray)
                            .padding(.horizontal, 10).padding(.vertical, 10)
                            .textCase(.uppercase)
                        
                        ForEach(dailyAction, id:\.id) {action in
                            ElementListeAction(action: action, actionDeJour: true)
                        }
                        
                        Spacer()
                        Text("Autres actions")
                            .font(.headline).foregroundColor(.gray)
                            .textCase(.uppercase)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 10)
                        
                        ForEach(actionList.filter{!dailyAction.map{$0.id}.contains($0.id)}, id:\.id){ action in
                            ElementListeAction(action: action)
                            Divider()
                        }
                        
                        
                    }
                    
                    
                }
            }
            
           
            .navigationBarHidden(true).navigationBarTitleDisplayMode(.inline)
        }
    }
}



struct Actions_Previews: PreviewProvider {
    static var previews: some View {
        Actions()
    }
}
