//
//  Classement.swift
//  AppEnvironnement
//
//  Created by NGO HO Anh Khoa on 29/04/2021.
//

import SwiftUI


struct Classement: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    @State private var selectedSegmentIndex = 0
    
    @ObservedObject var mainProfileObservedObject = mainProfile
    
    let sortedProfileList = profilList.sorted(by: {$0.score > $1.score})
    let sortedProfileTop10List: ArraySlice<Profil>
    var sortedProfileFrendList = [mainProfile]
    
    init() {
        
        let maxProfileNumber = sortedProfileList.count < 10 ? sortedProfileList.count-1 : 9
        self.sortedProfileTop10List = self.sortedProfileList[0...maxProfileNumber]
        
        self.sortedProfileFrendList = sortedProfileList.filter{ self.mainProfileObservedObject.amis.contains($0.id)}

        }
    
    var body: some View {
        VStack {
            GeometryReader {reader in
                HStack {
                    Button(action: {self.presentationMode.wrappedValue.dismiss()},
                           label:{
                            Image(systemName: "chevron.backward").accentColor(.gray)
                            Text("Profil").foregroundColor(.gray)})
                        .frame(width: reader.size.width * (1/3) - 10, alignment: .leading)
                        .padding(.leading, 10)

                    Spacer()
                    Text("Classement").bold()
                        .foregroundColor(Color("vert2")).font(.title2)
                        .frame(width: reader.size.width * (2/3), alignment: .leading)
                    
                    Spacer()
                    /*
                    HStack {
                        
                    }.frame(width: reader.size.width * (1/3) - 20, alignment: .trailing).padding(.trailing, 20)
                    */
                }
            }.frame(height: 30)
            
            ScrollView {
                ClassementButton(placement: mainProfileObservedObject.getPlacement(), avatar: mainProfileObservedObject.avatarURL)
                
                Picker("",
                       selection: $selectedSegmentIndex, content: {
                            Text("Top 10").tag(0)
                            Text("Amis").tag(1)})
                        .pickerStyle(SegmentedPickerStyle())
                        .padding()
                
                if selectedSegmentIndex == 0 {
                    ForEach(sortedProfileTop10List, id: \.id) {profil in
                        ElementListeRanking(userProfil: profil, positionRanking: profil.getPlacement(), isUser: profil.id == mainProfileObservedObject.id ? true: false)
                    }
                }
                else {
                    ForEach(sortedProfileFrendList, id: \.id) {profil in
                        ElementListeRanking(userProfil: profil, positionRanking: profil.getPlacement(), isUser: false)
                    }
                }
            }
            .navigationBarTitle("")
            .navigationBarBackButtonHidden(true)
            .navigationBarHidden(true)
        }
            
    }
}

struct Classement_Previews: PreviewProvider {
    static var previews: some View {
        Classement()
    }
}
