//
//  Accueil.swift
//  AppEnvironnement
//
//  Created by NGO HO Anh Khoa on 28/04/2021.
//


import SwiftUI

struct Accueil: View {
    @ObservedObject var mainProfileObservedObject = mainProfile
    @ObservedObject var challengeDatabaseObservedObject = challengeDatabase
    
    var body: some View {
        NavigationView{
            VStack {
                GeometryReader {reader in
                    HStack {
                        NavigationLink(
                            destination: PageProfil().navigationBarHidden(true),
                            label: {
                                Image (mainProfileObservedObject.avatarURL)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 45, height: 45)
                                    .cornerRadius(23)
                            }).frame(width: reader.size.width * (1/3) - 10, alignment: .leading)
                            .padding(.leading, 10)
                        
                        Image("DefiVert")
                            .resizable()
                            .scaledToFill()
                            .frame(width: reader.size.width * (1/3), alignment: .center)
                        
                        NavigationLink(
                            destination: Boutique().navigationBarHidden(true),
                            label: {
                                IconeNavigation(picto: "gift")
                            }).frame(width: reader.size.width * (1/3) - 30, alignment: .trailing).padding(.trailing, 30)
                    }
                }.frame(height: 50)
                
                GeometryReader {reader in
                    
                    ScrollView {
                        HStack{
                            PlanetJauge(scoreUser: mainProfileObservedObject.score, scoreMax: mainProfileObservedObject.scoreMax)
                            
                            VStack(alignment: .leading){
                                
                                Text (mainProfileObservedObject.fullName).foregroundColor(Color("vert4")).bold()
                                Text(mainProfileObservedObject.rank.rawValue).foregroundColor(Color("vert1"))
                                
                                HStack{
                                    Text("\(mainProfileObservedObject.ecoPoint)")
                                    Image(systemName: "leaf.fill")
                                }.foregroundColor(Color("vert2"))
                            }
                        }
                        NavigationLink(
                            destination: Defienfant(challenge: oneChallengeForDay),
                            label: {
                                ElementListeDefi(nombrePoint: oneChallengeForDay.score,
                                                 nombreParticipant: oneChallengeForDay.getNombreParticipant(challengeDatabaseObservedObject: challengeDatabaseObservedObject),
                                                 photoDefi: oneChallengeForDay.photoURL,
                                                 titreDefi: oneChallengeForDay.name,
                                                 challengedujour: oneChallengeForDay.challengedujour,
                                                 widthScreen: reader.size.width)
                            })
                        
                        HStack{
                            Text("Actions du jour")
                                .foregroundColor(Color("vert1")).bold()
                                .font(.system(size: 20)).frame(width: 150, height: 50)
                            Spacer()
                            /*
                             Image(systemName: "leaf.fill").foregroundColor(.gray)
                             Text("x2").foregroundColor(.gray).padding(.trailing, 10)
                             */
                        }
                        
                        ForEach(dailyAction, id:\.id) {action in
                            ElementListeAction(action: action, actionDeJour: true)
                        }
                        
                    }
                }
            }
            .navigationBarHidden(true).navigationBarTitleDisplayMode(.inline)
        }
        
    }
}

struct Accueil_Previews: PreviewProvider {
    static var previews: some View {
        Accueil()
    }
}

