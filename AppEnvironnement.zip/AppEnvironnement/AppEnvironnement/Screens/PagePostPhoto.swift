//
//  PagePostPhoto.swift
//  AppEnvironnement
//
//  Created by Mayte on 04/05/2021.
//

import SwiftUI

struct PagePostPhoto: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @ObservedObject var postDatabaseObservedObject = postDatabase
    @ObservedObject var mainProfileObservedObject = mainProfile
    @State var showingPrisPhotoView = false
    
    @State var text: String = "Partage ton experience"
    @State var showImage: Bool = false
    var body: some View {
        VStack {
            HStack {
                Button(action: {self.presentationMode.wrappedValue.dismiss()},
                       label:{
                        Image(systemName: "chevron.backward").accentColor(.gray)
                        Text("Communauté").foregroundColor(.gray)})
                    .frame(width: UIScreen.main.bounds.width * (1/3) - 10, alignment: .leading)
                    .padding(.leading, 10)

                Spacer()
                Text("Publication").bold()
                    .foregroundColor(Color("vert2")).font(.title2)
                    .frame(width: UIScreen.main.bounds.width * (2/3), alignment: .leading)
                
                Spacer()
            }.frame(height: 30)
            
            ScrollView {
                TextEditor(text: $text)
                    .frame(width: UIScreen.main.bounds.width*0.80, height: 200)
                    .foregroundColor(self.text == "Partage ton experience" ? .gray : Color("vert1"))
                    .overlay(RoundedRectangle(cornerRadius: 12)
                                .stroke(Color("vert3"), lineWidth: 2))
                    .onTapGesture {
                        if self.text == "Partage ton experience" {
                            self.text = ""
                        }
                    }
                
                Image("pipiDouche")
                    .resizable()
                    .scaledToFit()
                    .frame(width: UIScreen.main.bounds.width*0.80, height: UIScreen.main.bounds.width*0.80).opacity(showImage ? 1 : 0)
 
            }
            
            HStack {
                
                Button(action: {
                        showingPrisPhotoView.toggle()},
                       label: {
                        Image(systemName: "camera.circle.fill")
                            .resizable()
                            .foregroundColor(Color("vert2"))
                            .frame(width: 70, height: 70)
                            .padding(.leading, 20)
                       }
                ).fullScreenCover(isPresented: $showingPrisPhotoView, content: {
                                    PrisPhotoView(showImage: $showImage) })
                
                
                
                
                Button(action: {
                    if textAppropiate() {
                        post(text: self.text)
                        self.presentationMode.wrappedValue.dismiss()
                    }
                }, label: {
                    Text("Partager").bold()
                        .font(Font.title3)
                        .foregroundColor(.white)
                        .frame(width: UIScreen.main.bounds.width - 110, height: 70)
                        .background(textAppropiate() ? Color("vert2"): Color.gray)
                        .cornerRadius(30)
                        .padding(.trailing, 20)
                }).disabled(!textAppropiate())
                
            }.frame(width: UIScreen.main.bounds.width)
            .padding(.bottom, 10)

        }
        .navigationBarHidden(true).navigationBarTitleDisplayMode(.inline)
    }

    func textAppropiate() -> Bool {
        //check le text
        if text.count >= 3  && text != "Partage ton experience" {
            return true
        }
        return false
    }
    
    func post(text: String) {
        postDatabaseObservedObject.postList.insert(Post(imagePost: "pipiDouche", isLike: false, user: mainProfile, message: text), at: 0)

    }
    
}
    

struct PrisPhotoView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var mainProfileObservedObject = mainProfile
    @Binding var showImage: Bool
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                HStack {
                    Spacer()
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                        
                    }, label: {
                        Image(systemName: "xmark")
                            .font(.system(size:25))
                            .foregroundColor(.white)
                        
                    }).padding(.trailing, 20)
                }.padding(.top, 10)
                
                Spacer().frame(height: 40)
                HStack {
                    
                    Image(systemName: "bolt.slash.fill")
                        .font(.system(size:30))
                        .foregroundColor(.white)
                    Spacer()
                    Image(systemName: "timer")
                        .font(.system(size:30))
                        .foregroundColor(.white)
                    Spacer()
                    Image(systemName: "camera.filters")
                        .font(.system(size:30))
                        .foregroundColor(.white)
                    
                }.padding(.horizontal, 20)
                
                Spacer()

                Image("pipiDouche")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 350, height: 350)
                    .padding()
                
                Spacer()
                
                HStack {
                    Spacer()
                    
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                        showImage = true
                    }, label: {
                        AppareilButton()
                    })
                    
                    Spacer()
                }
                
                
                Spacer().frame(height: 30)
                
                HStack{
                    Image(systemName: "photo.fill.on.rectangle.fill")
                        .font(.system(size:40))
                        .foregroundColor(.white)
                    
                    Spacer().frame(width: 150, height: 40)
                    
                    Image(systemName: "arrow.triangle.2.circlepath.camera.fill")
                        .font(.system(size:40))
                        .foregroundColor(.white)
                    
                }
                
            }
            
        }
            
    }
}

struct PagePostPhoto_Previews: PreviewProvider {
    static var previews: some View {
        PagePostPhoto()
    }
}
