//
//  DetailProduit.swift
//  AppEnvironnement
//
//  Created by nicolas on 29/04/2021.
//

import SwiftUI

struct DetailProduit: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    let leProduit : Produit
    @ObservedObject var mainProfileObservedObject = mainProfile
    var hasPoint : Bool {
        if leProduit.prix < mainProfileObservedObject.ecoPoint{
            return true
        }
        else{
            return false
        }
    }
    var body: some View {
        NavigationView {
            VStack {
                //Navigation
                HStack {
                    Button(action: {self.presentationMode.wrappedValue.dismiss()},
                           label:{
                            Image(systemName: "chevron.backward").accentColor(.gray)
                            Text("Boutique").foregroundColor(.gray)})
                        .padding(.leading, 10)
                    
                    Spacer()
                    HStack {
                        Text("Solde :").foregroundColor(.gray).font(.system(size: 15))
                        Text(mainProfileObservedObject.getEcoPoint()).font(.system(size: 15)).fontWeight(.medium)
                        Image(systemName: "leaf.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 15, height: 15)
                    }.foregroundColor(Color("vert2"))
                    .padding(.trailing)
                }.frame(height: 30)
                
                //Detail du Produit
                ScrollView{
                    VStack(alignment: .leading){
                        
                        Image(leProduit.image)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(height: 200)
                            .clipped()
                        
                        VStack(alignment: .leading){
                            Text(leProduit.nom).font(Font.title.bold()).foregroundColor(Color("vert1"))
                                .padding(.leading, 10)
                            Text(" \(leProduit.prix) \(Image(systemName: "leaf.fill")) ")
                                .font(.title3)
                                .foregroundColor(Color("vert2"))
                                .padding(.leading, 10)
                            
                            
                            Text( leProduit.description ).foregroundColor(Color("vert4"))
                                .multilineTextAlignment(.leading)
                                .padding(10)
                            
                            
                            Section{
                                switch hasPoint{
                                case true :
                                    
                                    Button(action: {
                                        mainProfileObservedObject.buyProduct(product: leProduit)
                                    }, label: {
                                        Text("J'echange \(leProduit.prix) \(Image(systemName: "leaf.fill"))  EcoPoint").bold()
                                            .font(Font.title3)
                                            .frame(width: UIScreen.main.bounds.width*0.90)
                                            .padding(10)
                                            .foregroundColor(.white)
                                            .background(Color("vert2"))
                                            .cornerRadius(30)
                                    })
                                    
                                case false:
                                    Text("Vous n'avez pas assez de point").bold()
                                        .font(Font.title3)
                                        .frame(width: UIScreen.main.bounds.width*0.90)
                                        .padding(10)
                                        .foregroundColor(.gray)
                                        .background(Color("gris"))
                                        .cornerRadius(30)
                                }
                            }
                            
                            
                        }.padding()
                        
                        
                    }
                    
                }
                
            }
            
            
            .navigationBarHidden(true).navigationBarTitleDisplayMode(.inline)
        }
        
        
    }
}



struct DetailProduit_Previews: PreviewProvider {
    static var previews: some View {
        DetailProduit(leProduit : restauration[0])
    }
}

