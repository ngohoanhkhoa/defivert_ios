//
//  JeuxPoubelle.swift
//  AppEnvironnement
//
//  Created by Cécile MARTIN-PRUD'HOMME on 05/05/2021.
//

import SwiftUI

struct JeuxPoubelle: View {
    @Environment(\.presentationMode) var presentationMode
    @State var showingModal : Bool = false
    var body: some View {
        ZStack{
            Color("saumon")
                .ignoresSafeArea()
            VStack{
                HStack {
                    Spacer()
                    Button(action: {self.presentationMode.wrappedValue.dismiss()},
                           label:{
                            Image(systemName:"xmark.circle.fill")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 30, height: 30)
                                .foregroundColor(Color("saumon2"))
                           })
                        .frame(alignment: .leading)
                        .padding(.trailing, 20)
                    
                    
                }.frame(height: 30)
                Spacer()
                
                Image(systemName: "trash.fill")
                    .resizable()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.white)
                
            
                Text("Jeux à venir")
                    .foregroundColor(.white)
                    .font(Font.largeTitle.bold())
                
                HStack {
                    Text("10")
                        .foregroundColor(.white).font(.largeTitle)
                    Image(systemName: "leaf.fill")
                        .resizable()
                        .frame(width: 40, height: 40)
                        .foregroundColor(.white)
                }
                Spacer()
            }.fullScreenCover(isPresented: $showingModal ){
                
            }
        }
        .navigationBarTitle("")
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
}

struct JeuxPoubelle_Previews: PreviewProvider {
    static var previews: some View {
        JeuxPoubelle()
    }
}
