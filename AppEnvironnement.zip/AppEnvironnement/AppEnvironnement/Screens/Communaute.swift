//
//  Communaute.swift
//  AppEnvironnement
//
//  Created by NGO HO Anh Khoa on 28/04/2021.
//

import SwiftUI

struct Communaute: View {
    @ObservedObject var postDatabaseObservedObject = postDatabase
    @State var showingPagePhoto = false
    
    var body: some View {
        NavigationView {
            VStack {
                
                HStack {
                    Text("Communauté").bold()
                        .foregroundColor(Color("vert2")).font(.title2)
                    Spacer()
                    HStack {
                        NavigationLink(
                            destination: PagePostPhoto().navigationBarHidden(true),
                            label: {
                                IconeNavigation(picto: "plus.circle.fill")
                            })}.padding(.trailing, 10)
                }.frame(height: 30).padding(10)
                
                ScrollView {
                    ForEach(postDatabaseObservedObject.postList, id:\.id){ post in
                        PostPhoto(post: post)
                        Divider()
                    }
                    
                }
                
            }
            
            .navigationBarHidden(true).navigationBarTitleDisplayMode(.inline)
        }
        
    }
}

struct Communaute_Previews: PreviewProvider {
    static var previews: some View {
        Communaute()
    }
}
