//
//  Quizz.swift
//  AppEnvironnement
//
//  Created by Cécile MARTIN-PRUD'HOMME on 29/04/2021.
//

import SwiftUI

struct Quizz: View {
    @Environment(\.presentationMode) var presentationMode
    
    @ObservedObject var mainProfileObservedObject = mainProfile
    @State var questions = questionList.shuffled()
    
    let columns = [
        GridItem(spacing: 10),
        GridItem(spacing: 10),
    ]
    @State var showingModal : Bool = false
    @State var gameOver : Bool = false
    @State var isCorrect : Bool = false
    @State var selectedQuestion : String = ""
    @State var reponseJoueur : String = ""
    @State var bonneReponse: String = ""
    @State var i :Int = 0
    @State var point : Int = 0
    
    // Khoa ---
    @State private var minutes: Int = minutesMax
    @State private var seconds: Int = secondsMax
    // Khoa ---
    
    func checkResponse(reponse: String, bonneReponse: String) {
        
        if reponse == bonneReponse{
            isCorrect = true
            showingModal = true
            point+=1
            
        }else {
            isCorrect = false
            showingModal = true
            
            print("la valeur de i  en perdu",i)
            
            
        }
    }
    
    func pointGagne() {
        switch  point {
        case 1 :
            mainProfile.addScore(point: 10)
        case 2 :
            mainProfile.addScore(point: 20)
        case 3 :
            mainProfile.addScore(point: 30)
        case 4 :
            mainProfile.addScore(point: 40)
        case 5 :
            mainProfile.addScore(point: 50)
        default:
            mainProfile.addScore(point: 0)
        }
    }
    
    
    var body: some View {
        ZStack {
            // PATCH : incident de transferts de donnée  de la modale
            Text(selectedQuestion)
            Color("bleu2").ignoresSafeArea()
            
            VStack {
                HStack {
                    
                    Spacer()
                    Button(action: {self.presentationMode.wrappedValue.dismiss()},
                           label:{
                            Image(systemName:"xmark.circle.fill")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 30, height: 30)
                                .foregroundColor(Color("vert1"))
                           })
                        .frame(alignment: .leading)
                        .padding(.trailing, 20)
                        .opacity(gameOver ? 0 : 1)
                        .disabled(gameOver)
                    
                    
                }.frame(height: 30)
                

                
                if gameOver {
                    Text(point > 0 ? "🥳": "😥").font(.system(size: 200))
                    Spacer().frame(height: 75)
                    Text(point > 0 ? "Vous avez gagné \(point)0 points":"Dommage, vous ferez mieux la prochaine fois!").bold().padding(.horizontal, 20)
                        .foregroundColor(Color("vert1")).font(.title)
                    Spacer().frame(height: 30)
                    BoutonValider2(action: {
                        pointGagne()
                        presentationMode.wrappedValue.dismiss()
                    },
                    textBouton:   "Retour aux jeux")
                }
                else{
                    
                    Text("Question \(i+1) /5 " ).font(Font.title2.bold()).foregroundColor(Color("bleu1")).padding(.top)

                    quizzQuestion(numQuest: questions[i].score ,
                                  question: questions[i].question,
                                  minutes: $minutes,
                                  seconds: $seconds).padding(.horizontal, 30)
                        .onChange(of: minutes+seconds) { value in
                            if value == 0 {
                                isCorrect = false
                                showingModal = true
                                selectedQuestion = questions[i].explicationReponse
                            }
                        }

                    
                    LazyVGrid (columns: columns, spacing: 10){
                        
                        Button(action: {
                            selectedQuestion = questions[i].explicationReponse
                            checkResponse(reponse: questions[i].reponses[0], bonneReponse: questions[i].bonneReponse)
                            
                        },
                        label: {
                            BoutonJeux(textReponse: questions[i].reponses[0] ,couleurBouton: Color("vert1"))
                        }).padding(.leading, 30)
                        
                        Button(action: {
                            selectedQuestion = questions[i].explicationReponse
                            checkResponse(reponse: questions[i].reponses[1], bonneReponse: questions[i].bonneReponse)
                            
                        },
                        label: {
                            BoutonJeux(textReponse: questions[i].reponses[1] ,couleurBouton: Color("saumon"))
                        }).padding(.trailing, 30)
                        
                        Button(action: {
                            selectedQuestion = questions[i].explicationReponse
                            checkResponse(reponse: questions[i].reponses[2], bonneReponse: questions[i].bonneReponse)
                            
                        },
                        label: {
                            BoutonJeux(textReponse: questions[i].reponses[2] ,couleurBouton: Color("vert2"))
                        }).padding(.leading, 30)
                        
                        Button(action: {
                            selectedQuestion = questions[i].explicationReponse
                            checkResponse(reponse: questions[i].reponses[3], bonneReponse: questions[i].bonneReponse)
                        },
                        label: {
                            BoutonJeux(textReponse: questions[i].reponses[3] ,couleurBouton: Color("bleu1"))
                        }).padding(.trailing, 30)
                        
                        
                    }
                }
                
                Spacer()
            }.fullScreenCover(isPresented: $showingModal ){
                
                //Khoa -------
                JeuxEnfants1(reponseStatut: isCorrect, explicationReponse: selectedQuestion, numQuestion: $i,isOver : $gameOver ,hideHimself: $showingModal, minutes: $minutes, seconds: $seconds)
                //Khoa -------
            }
        }
        //Khoa .........
        .navigationBarTitle("")
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
        //Khoa .........
    }
}


struct Bravo : View {
    @Binding var  Score : Int
    var body : some View {
        ZStack{
            
        }
    }
}
struct Quizz_Previews: PreviewProvider {
    static var previews: some View {
        Quizz()
    }
}
