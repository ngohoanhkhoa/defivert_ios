//
//  Boutique.swift
//  AppEnvironnement
//
//  Created by nicolas on 29/04/2021.
//

import SwiftUI

struct Boutique: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    let loupe  : Image = Image(systemName:"magnifyingglass")
    @State var recherche : String = ""
    
    @ObservedObject var mainProfileObservedObject = mainProfile

    var body: some View {
        NavigationView {
            VStack{
                GeometryReader {reader in
                    HStack {
                        Button(action: {self.presentationMode.wrappedValue.dismiss()},
                               label:{
                                Image(systemName: "chevron.backward").accentColor(.gray)
                                Text("Accueil").foregroundColor(.gray)})
                            .frame(width: reader.size.width * (1/3) - 10, alignment: .leading)
                            .padding(.leading, 10)
                        
                        Spacer()
                        Text("Boutique").bold()
                            .foregroundColor(Color("vert2")).font(.title2)
                            .frame(width: reader.size.width * (1/3), alignment: .center)
                        
                        Spacer()
                        
                        HStack {
                            Text("Solde: ").foregroundColor(.gray).font(.system(size: 15))
                            Text(mainProfileObservedObject.getEcoPoint()).font(.system(size: 15)).fontWeight(.medium)
                            Image(systemName: "leaf.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 15, height: 15)
                        }.foregroundColor(Color("vert2"))
                        .frame(width: reader.size.width * (1/3) - 30, alignment: .trailing).padding(.trailing, 30)
                    }
                }.frame(height: 30)
                
                //SearchBar
                TextField(" \(loupe) Search", text: $recherche)
                    .foregroundColor(Color("vert2"))
                    .padding(5)
                    .background(Color("gris"))
                    .cornerRadius(15)
                    .padding(.horizontal, 15)
                
                // Debut de la boutique
                ScrollView{
                    VStack(alignment: .leading){
                        //Categorie 1
                        Text("Restauration")
                            .font(Font.title3.bold())
                            .foregroundColor(Color("vert1"))
                            .padding(.leading)
                            .padding(.top)
                        ListeHorizontale(produits: restauration)
                        
                    
                        //Categorie 2
                        Text("Atelier D.I.Y.")
                            .font(Font.title3.bold())
                            .foregroundColor(Color("vert1"))
                            .padding(.leading)
                            .padding(.top)
                        ListeHorizontale(produits: atelierDIY)
                       
                        //Categorie 3
                        Text("Bon de réduction")
                            .font(Font.title3.bold())
                            .foregroundColor(Color("vert1"))
                            .padding(.leading)
                            .padding(.top)
                        ListeHorizontale(produits: bonReduction)
                        
                    
                        //Categorie 4
                        Text("Goodies")
                            .font(Font.title3.bold())
                            .foregroundColor(Color("vert1"))
                            .padding(.leading)
                            .padding(.top)
                        ListeHorizontale(produits: goodise)
                         
                    }//.padding()
                }
            }
            .navigationBarHidden(true).navigationBarTitleDisplayMode(.inline)
        }
    }
}



struct Boutique_Previews: PreviewProvider {
    static var previews: some View {
        Boutique()
    }
}
