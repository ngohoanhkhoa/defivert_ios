//
//  Jeux.swift
//  AppEnvironnement
//
//  Created by NGO HO Anh Khoa on 28/04/2021.
//

import SwiftUI

struct Jeux: View {
    
    @ObservedObject var mainProfileObservedObject = mainProfile
    
    var body: some View {
        NavigationView {
            VStack{
                HStack {
                    Text("Jeux").bold()
                        .foregroundColor(Color("vert2")).font(.title2)
                    Spacer()
                    HStack {
                        Text("Solde :").foregroundColor(.gray).font(.system(size: 15))
                        Text(mainProfileObservedObject.getEcoPoint()).font(.system(size: 15)).fontWeight(.medium)
                        Image(systemName: "leaf.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 15, height: 15)
                    } .foregroundColor(Color("vert2"))
                }.frame(height: 30).padding(10)
                
                ZStack {
                    
                    Color("bleu2")
                    
                    VStack  {
                        
                        
                        HStack {
                            NavigationLink(
                                destination: Quizz(),
                                label: {
                                    BoutonChoixJeux(nomDuJeux: "Quizz", imagDuJeux: "questionmark", nombresDePoint: "50", couleuDeFond: Color("vert1"))
                                })
                            NavigationLink(
                                destination: JeuxExtra(),
                                label: {
                                    BoutonChoixJeux(nomDuJeux: "Jeux", imagDuJeux: "drop.triangle.fill", nombresDePoint: "10", couleuDeFond: Color("bleu1"))
                                })
                        }
                        HStack {
                            NavigationLink(
                                destination: JeuxPuzzle(),
                                label: {
                                    BoutonChoixJeux(nomDuJeux: "Puzzle", imagDuJeux: "puzzlepiece.fill", nombresDePoint: "10", couleuDeFond: Color("vert2"))
                                })
                            NavigationLink(
                                destination: JeuxPoubelle(),
                                label: {
                                    BoutonChoixJeux(nomDuJeux: "Jeux", imagDuJeux: "trash.fill", nombresDePoint: "10", couleuDeFond: Color("saumon"))
                                })
                        }
                    }
                }
                
            }
            
            .navigationBarHidden(true).navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct Jeux_Previews: PreviewProvider {
    static var previews: some View {
        Jeux()
    }
}
