//
//  JeuxPuzzle.swift
//  AppEnvironnement
//
//  Created by Mayte on 05/05/2021.
//

import SwiftUI

struct JeuxPuzzle: View {
    @Environment(\.presentationMode) var presentationMode
    @State var showingModal : Bool = false
    var body: some View {
        ZStack{
            Color("vert2")
                .ignoresSafeArea()
            VStack{
                HStack {
                    Spacer()
                    Button(action: {self.presentationMode.wrappedValue.dismiss()},
                           label:{
                            Image(systemName:"xmark.circle.fill")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 30, height: 30)
                                .foregroundColor(Color("vert3"))
                           })
                        .frame(alignment: .leading)
                        .padding(.trailing, 20)
                    
                    
                }.frame(height: 30)
                Spacer()
                
                Image("recyclage")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                
                Image("puzzle")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 350, height: 350)
                
               
                
                HStack {
                    Text("10")
                        .foregroundColor(.white).font(.largeTitle)
                    Image(systemName: "leaf.fill")
                        .resizable()
                        .frame(width: 40, height: 40)
                        .foregroundColor(.white)
                }
                Spacer()
            }.fullScreenCover(isPresented: $showingModal ){
                
            }
        }
        .navigationBarTitle("")
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
}

struct JeuxPuzzle_Previews: PreviewProvider {
    static var previews: some View {
        JeuxPuzzle()
    }
}
