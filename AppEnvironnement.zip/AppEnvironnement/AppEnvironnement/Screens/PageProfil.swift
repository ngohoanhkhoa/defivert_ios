//
//  PageProfil.swift
//  AppEnvironnement
//
//  Created by Mayte on 29/04/2021.
//

import SwiftUI

struct PageProfil: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @ObservedObject var mainProfileObservedObject = mainProfile
    @ObservedObject var challengeDatabaseObservedObject = challengeDatabase
    
    @State private var showingActionSheet = false
    @State private var showingFriendSheet = false
    @State private var showingDefisSheet = false
    @State private var showingCadeauxSheet = false
    
    var body: some View {
        NavigationView{
            VStack {
                GeometryReader {reader in
                    VStack {
                        
                        HStack {
                            Button(action: {self.presentationMode.wrappedValue.dismiss()},
                                   label:{
                                    Image(systemName: "chevron.backward").accentColor(.gray)
                                    Text("Accueil").foregroundColor(.gray)})
                                
                                .frame(width: reader.size.width * (1/3) - 10, alignment: .leading)
                                .padding(.leading, 10)

                            Spacer()
                            
                            Text("Profil").bold()
                                .foregroundColor(Color("vert2")).font(.title2)
                                .frame(width: reader.size.width * (1/3), alignment: .center)
                            
                            Spacer()
                            
                            HStack {
                                NavigationLink(
                                    destination: Classement().navigationBarHidden(true),
                                    label: {
                                        IconeNavigation(picto: "crown")
                                    }).padding(.trailing)
                                
                            }.frame(width: reader.size.width * (1/3) - 30, alignment: .trailing)
                        }.frame(height: 30)
                        
                        
                        ScrollView {
                            
                            
                            HStack (alignment: .top){
                                
                                VStack {
                                    Image(mainProfile.avatarURL)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: reader.size.width * (1/4), height: reader.size.width * (1/4))
                                        .cornerRadius(55)
                                        .foregroundColor(Color("vert1"))
                                    
                                    HStack (alignment: .lastTextBaseline) {
                                        Text(mainProfileObservedObject.getEcoPoint()).font(.title2).fontWeight(.medium)
                                        Image(systemName: "leaf.fill")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 18, height: 18)
                                    }.foregroundColor(Color("vert2"))
                                    .padding(.top, 10)
                                }.frame(width: reader.size.width * (1/3), alignment: .center)
                               
                                
                                
                                VStack(alignment: .leading, spacing:4){
                                    
                                    HStack {
                                        Text (mainProfileObservedObject.fullName)
                                            .foregroundColor(Color("vert4"))
                                            .bold().font(.title2)
                                    }
                                    
                                    Text(mainProfileObservedObject.rank.rawValue)
                                        .foregroundColor(Color("vert1")).bold()
                                    Text("@\(mainProfileObservedObject.name)").foregroundColor(.gray)
                                    Text("\(mainProfileObservedObject.getNumFriend())  amis").foregroundColor(.gray)
                                    
                                    
                                    
                                }.frame(width: reader.size.width * (2/3) - 30, alignment: .leading)
                                
                                
                            }.padding(.top, 20)
                            

                            HStack {
                                Text("Eco-niveau")
                                    .foregroundColor(Color("vert1"))
                                    .font(.footnote).bold()
                                ProgressView(value: Double(mainProfileObservedObject.score), total: Double(mainProfileObservedObject.scoreMax) )
                                    .accentColor(Color("vert2"))
                                Image("terre")
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 30, height: 30)
                                    .foregroundColor(Color("vert2"))
                            }.padding(.horizontal)
                            
                            Divider()
                            
                            Button(action: {showingActionSheet.toggle()},
                                   label: {
                                    ElementSectionProfil(picto: "hare", mainColor: Color("saumon"), bkgColor: Color("saumon2"), titleSection: "Mes Actions")
                                    
                                   }
                            ).sheet(isPresented: $showingActionSheet) {
                                ActionSheetView()
                            }
                            
                            Button(action: {showingFriendSheet.toggle()},
                                   label: {
                                    ElementSectionProfil(picto: "person.2", mainColor: Color("bleu1"), bkgColor: Color("bleu2"), titleSection: "Mes amis")
                                    
                                   }
                            ).sheet(isPresented: $showingFriendSheet) {
                                FriendSheetView()
                            }
                            
                            Button(action: {showingDefisSheet.toggle()},
                                   label: {
                                    ElementSectionProfil(picto: "stopwatch", mainColor: Color("vert2"), bkgColor: Color("vert3"), titleSection: "Mes défis déjà realisés")
                                    
                                   }
                            ).sheet(isPresented: $showingDefisSheet) {
                                DefisSheetView()
                            }
                            
                            
                            Button(action: {showingCadeauxSheet.toggle()},
                                   label: {
                                    ElementSectionProfil(picto: "gift", mainColor: Color("vert1"), bkgColor: Color("vert2"), titleSection: "Mes cadeaux obtenus")
                                    
                                   }
                            ).sheet(isPresented: $showingCadeauxSheet) {
                                CadeauxSheetView()
                            }
                            
                            Spacer().frame(height: 20)
                            
                            HStack{
                                Text("Défis en cours")
                                    .foregroundColor(Color("vert1")).bold()
                                    .textCase(.uppercase)
                                    .padding(.leading, 10)
                                Spacer()
                                Text("\(mainProfileObservedObject.getNumChallengeInProgress()) " + (mainProfileObservedObject.getNumChallengeInProgress() == 1 ? "défi" : "défis") )
                                    .foregroundColor(.gray)
                                    .padding(.trailing, 10)
                            }
                            
                            
                            ForEach(mainProfileObservedObject.getChallengeInProgress(), id: \.id) {challenge in
                                NavigationLink(
                                    destination: Defienfant(challenge: challengeList.filter{$0.id == challenge.challengeId}[0]),
                                    label: {
                                        ElementListeDefi(nombrePoint: challengeList.filter{$0.id == challenge.challengeId}[0].score,
                                                         nombreParticipant: challengeList.filter{$0.id == challenge.challengeId}[0].getNombreParticipant(challengeDatabaseObservedObject: challengeDatabaseObservedObject),
                                                         photoDefi: challengeList.filter{$0.id == challenge.challengeId}[0].photoURL,
                                                         titreDefi: challengeList.filter{$0.id == challenge.challengeId}[0].name,
                                                         challengedujour: challengeList.filter{$0.id == challenge.challengeId}[0].challengedujour,
                                                         widthScreen: reader.size.width)
                                    })
                            }
                            
                        }
                    }
                    
                    
                    .navigationBarHidden(true).navigationBarTitleDisplayMode(.inline)
                }
            }
        }
    }
}

struct PageProfil_Previews: PreviewProvider {
    static var previews: some View {
        PageProfil()
    }
}


struct ActionSheetView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var mainProfileObservedObject = mainProfile
    
    init() {
    }
    var body: some View {
        VStack {
            HStack{
                Text("Mes actions").padding().foregroundColor(Color("saumon"))
                    .font(.title)
            Spacer()
            Button(action: {
                presentationMode.wrappedValue.dismiss()
                    
                }, label: {
                    IconeNavigation(picto: "xmark.circle.fill")
                }).padding(.trailing, 20)
            }
            ScrollView{
                ForEach(Array(mainProfileObservedObject.getFinishedAction().keys), id: \.self) {actionKey in
                    ActionDonneProfil(actionName: actionList.filter{$0.id == actionKey}[0].name,
                                      descriptionAction: actionList.filter{$0.id == actionKey}[0].description,
                                      nombreDeFois: mainProfileObservedObject.getFinishedAction()[actionKey] ?? 0)
                }
            }
        }
    }
}

struct FriendSheetView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var mainProfileObservedObject = mainProfile
    var profileFrendList = [mainProfile]
    
    init() {
        
        self.profileFrendList = profilList.filter{ self.mainProfileObservedObject.amis.contains($0.id)}
    }
    var body: some View {
        VStack {
            HStack{
                Text("Mes amis").padding().foregroundColor(Color("bleu1"))
                    .font(.title)
            Spacer()
            Button(action: {
                presentationMode.wrappedValue.dismiss()
                    
                }, label: {
                    IconeNavigation(picto: "xmark.circle.fill")
                }).padding(.trailing, 20)
            }
            ScrollView{
                ForEach(self.profileFrendList, id: \.id) {friend in
                    AmisProfil(userProfil: friend)
                }
            }
        }
    }
}

struct DefisSheetView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var mainProfileObservedObject = mainProfile
    
    var body: some View {
        VStack {
            HStack{
                Text("Mes défis").padding().foregroundColor(Color("vert2"))
                    .font(.title)
            Spacer()
            Button(action: {
                presentationMode.wrappedValue.dismiss()
                    
                }, label: {
                    IconeNavigation(picto: "xmark.circle.fill")
                }).padding(.trailing, 20)
            }
            ScrollView{
                ForEach(mainProfileObservedObject.getChallengeFinished(), id: \.id) {challenge in
                    DefisDonneProfil(challengeId: challenge.challengeId, challengeFinishDate: challenge.dateFinish, proposedByFriend: challenge.proposerId == challenge.receiverID ? nil : challenge.proposerId)
                }
            }
        }
    }
}

struct CadeauxSheetView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var mainProfileObservedObject = mainProfile
    
    var body: some View {
        VStack {
            HStack{
                Text("Mes cadeaux").padding().foregroundColor(Color("vert1"))
                    .font(.title)
            Spacer()
            Button(action: {
                presentationMode.wrappedValue.dismiss()
                    
                }, label: {
                    IconeNavigation(picto: "xmark.circle.fill")
                }).padding(.trailing, 20)
            }
            ScrollView{
                ForEach(mainProfileObservedObject.productBuyed, id: \.id) {productBuyed in
                    TicketBoutique(produit: productBuyed.product, dateBuy: productBuyed.dateBuy)
                }
            }
        }
    }
}


