//
//  Defienfant.swift
//  AppEnvironnement
//
//  Created by Célina Moussaoui on 29/04/2021.
//

import SwiftUI

struct Defienfant: View {
    @ObservedObject var mainProfileObservedObject = mainProfile
    @ObservedObject var challengeDatabaseObservedObject = challengeDatabase
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    let challenge: Challenge
    @State private var buttonIcon = "plus.circle"
    @State private var disableIcon = false
    @State private var durationByDay = 30

    var body: some View {
        ZStack {
            Color(challenge.challengedujour ? "vert1" : "bleu1").ignoresSafeArea()
            
            VStack(spacing: 0){
                HStack {
                    Button(action: {self.presentationMode.wrappedValue.dismiss()},
                           label:{
                            Image(systemName: "chevron.backward").accentColor(Color.white)
                            Text("Défis").foregroundColor(Color.white)})
                        
                        .padding(.leading, 10)
                    
                    Spacer()
                    
                }.frame(height: 30).background(Color(challenge.challengedujour ? "vert1" : "bleu1"))
                
                ScrollView{
                    
                    ZStack(alignment: .bottom) {
                        Image(challenge.photoURL)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(height: 200)
                            .clipped()
                    
                        Button(action: {modifyChallenge()},
                               label: {
                            ChallengeButton(buttonIcon: $buttonIcon, challengedujour: challenge.challengedujour)
                               }).disabled(disableIcon).alignmentGuide(.bottom) { d in d[.bottom] / 2 }
                    }
                    
                    Text(challenge.name)
                        .foregroundColor(.white)
                        .font(.title)
                        .bold()
                        .frame(alignment: .center)
                        .padding(.bottom,10)

                    
                    Text(mainProfileObservedObject.checkFinishedChallenge(challenge: challenge) ? "" : "\(durationByDay) JOURS RESTANTS")
                        .foregroundColor(Color("vert2")).padding(.bottom, 10)
                    
                    
                    HStack {
                        Text("\(challenge.score)")
                            .bold()
                            .foregroundColor(Color("vert2"))
                            .font(.system(size:20))
                        Image(systemName: "leaf")
                            .foregroundColor(Color("vert2"))
                            .font(.system(size:20))
                        Spacer()
                        Text("\(challenge.getNombreParticipant(challengeDatabaseObservedObject: challengeDatabaseObservedObject)) " + (challenge.getNombreParticipant(challengeDatabaseObservedObject: challengeDatabaseObservedObject) <= 1 ? "participant" : "participants") ).foregroundColor(Color("gris"))
                            .font(.system(size:17))
                            
                    }.padding(.bottom, 50)

                    
                    Text(challenge.description)
                        .foregroundColor(.white)
                        .font(.system(size:17))
                        .padding(.bottom, 50)
                    
                    BoutonValiderChallenge(challenge: challenge, buttonIcon: $buttonIcon, disableIcon: $disableIcon)
                        .opacity(mainProfileObservedObject.checkExistChallenge(challenge: challenge) ? 1 : 0)
                        .disabled(!mainProfileObservedObject.checkExistChallenge(challenge: challenge))

                    
                }.padding(10)
            }
            
        }.onAppear {
            if mainProfileObservedObject.checkFinishedChallenge(challenge: challenge) {
                self.buttonIcon = "checkmark.circle"
                self.disableIcon = true
                self.durationByDay = 0
            } else {
                if mainProfileObservedObject.checkExistChallenge(challenge: challenge) {
                    self.buttonIcon = "minus.circle"
                    self.durationByDay = mainProfileObservedObject.getDateFinishedChallenge(challenge: challenge)
                } else {
                    self.buttonIcon = "plus.circle"
                    self.durationByDay = challenge.durationByDay
                }
                
            }
        }.navigationBarTitle("")
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
        
    }
    
    func modifyChallenge() {
        if mainProfileObservedObject.checkExistChallenge(challenge: challenge) {
            mainProfileObservedObject.removeChallenge(challenge: challenge)
            buttonIcon = "plus.circle"
        } else {
            mainProfileObservedObject.addChallenge(challenge: challenge)
            buttonIcon = "minus.circle"
        }
    }
}

struct Defienfant_Previews: PreviewProvider {
    static var previews: some View {
        Defienfant(challenge : challengeList[0])
    }
}



